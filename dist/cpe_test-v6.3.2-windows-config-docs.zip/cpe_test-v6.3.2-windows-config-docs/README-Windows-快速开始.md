# CPE 测试工具 Windows 包

> 如果你从 Git 仓库下载的是 `cpe_test-v6.3.2-windows-config-docs.zip`，那是一份只含
> 配置、文档和启动脚本的资料包，不含 `cpe_test.exe`、`ctsTraffic.exe` 或 iperf3。
> 开箱即用请下载 GitHub Release 的 `cpe_test-v6.3.2-windows-x86_64.zip`；也可以自行
> 编译程序后，把资料包内容与 exe 放到同一目录。

将这个文件夹完整复制到**主控机**和**辅测机**。两台电脑必须使用同一个
`cpe_test` Release；不要只替换其中一台的 exe。

## 包内文件与系统要求

- `cpe_test.exe`：主控、agent、网卡扫描和监控共用的程序。
- `ctsTraffic.exe`：Microsoft ctsTraffic 2.0.4.0 x64，随官方 v6.3.2 Windows 包固定捆绑并校验；仅支持 Windows 10 或更高版本。
- `start_*.bat`：双击启动脚本。`start_ui.bat` 是图形控制台，`start_master*.bat` 是命令行问答式。
- `configs\`：SGMII、Wi-Fi、10GUSB 等具名配置。
- `THIRD_PARTY_NOTICES.md` 及 CTS/WIL 许可文件：第三方归属和许可说明。

iperf3 未内置：不同 Windows 发行版依赖的 DLL 不同。需要 iperf3 测试时，把和电脑
架构一致的完整 iperf3 发行包内容复制到本目录，包括 `iperf3.exe` 和同包 DLL
（常见为 `cygwin1.dll`）。只测 Ping 或 ctsTraffic 时不需要 iperf3；只测 Ping 时也不需要 CTS。

ctsTraffic 测试要求主控和辅测都是 Windows 10+，且两边都能在 `cpe_test.exe` 同目录
或 `PATH` 中找到 `ctsTraffic.exe`。程序会实际检查两端 Windows major 版本，只有不低于 10 才通过；
Windows 7/8/8.1、版本无法确认以及 macOS/Linux 都不支持 CTS，但不会阻断已选的 iperf3/Ping。

## 使用（图形控制台，推荐）

导入项目后，已确认缺失的网口对、空集合及失效分配会自动移除并提示；尚未连接或扫描失败的端点保留为“待校验”。连接或重扫成功后自动核对，套件和流量配置保留。

双向 iperf3 执行失败不代表未安装：按报告中的退出状态与原始输出检查端口、绑定地址和连接；只有前置检查明确提示缺少工具时才检查程序路径及 DLL。

监控更新失败会保留上次成功曲线并显示提示，恢复同步后自动清除；旧读数不能当作当前实时速率。

1. 辅测机双击 `start_agent.bat`，首次防火墙提示请选择“允许访问”。保持窗口打开。
   浏览器会自动打开辅测机状态页 `http://127.0.0.1:28802`，要报给主控的 IP 就在那张网卡表里，
   主控连上后还能看到它用的是哪一块、正在让本机做什么。
2. 主控机双击 `start_ui.bat`，浏览器会自动打开 `http://127.0.0.1:28800`。没弹出就手动复制这个地址。
3. 导航分为“测试流程”和“工具与记录”七个区，窄屏时横向排列；右上角可切换主题或点击运行状态查看进度：
   - **辅测机**：可从“本机”页点“连接辅测机”，填对端 IP 点“连接”。共享令牌默认隐藏，可点“显示”核对；地址最多 256 字节、令牌最多 4096 字节且不能含控制字符；成功后点“配置测试计划”继续。
   - **测试计划**：使用页面上方的三个标签处理“分配链路与套件 → 编辑套件 → 编辑流量配置”；
     可直接从页头“预览与执行”进入执行页；在分配表里勾「哪个链路集合跑哪个套件」；套件、任务（TCP/UDP/PING、方向、IP 版本）
     和 TCP/UDP 档位都在这一页直接编辑。TCP/UDP 任务里的「编辑参数 →」会直达对应配置；
     白底参数框可直接输入；套件和配置很多时各自在固定高度列表内滚动，不会拉长整页。
     新任务默认选 IPv4+IPv6，PING 不显示吞吐 Mbps 门限。旧草稿可用「恢复默认计划」一次重置。
   - **执行**：填每单元时长；展开“全局默认档位与判定门限”调整高级设置。「全局默认档位」出厂就是 UDP `-b 2500m`、TCP `-w 4m`、
     `-l` 留空（不下发）。Ping 高级阈值空格会以灰字显示当前生效的“默认 xx”，填值后才覆盖。
     这些默认值是**内置的**，不看 exe 旁边的 `config.json`（那份只提供辅测机地址与网段信息），
     所以两台装了同一个 exe 的机器控制台开局一模一样。
     两端都是 Wi-Fi 时，「Wi-Fi 互测门限」只显示实际识别到的频段组合；每个组合三格：
     单向主控→辅测、单向辅测→主控、**双向 RX 合计**。双向并发按
     `主控端 RX 平均 + 辅测端 RX 平均 ≥ 合计门限` 判定，不要求两个方向各达到一半——
     Wi-Fi 之间抢的是同一段空口时间。具体网卡差异在「按网口门限与负载」里填 RX 门限
     （`1800` 或 `90%`）、发送端 UDP `-b` 和 `-l`；
     需要时勾「按链路上限裁剪 UDP 发送速率」（默认不勾）。
   - 点“预览”确认单元数和预计耗时 → 点“开始测试”。预览后若再改任何计划或运行参数，
     必须按提示“重新预览”，旧计划不会被误启动。
4. **进度**页实时显示每个单元的判定；要提前收尾回到“执行”页点“停止”（跑完当前单元再出报告），
   跑完后点“打开报告”。**历史运行**页能下载整个运行目录、从结果明细恢复报告、
   或把某一轮的计划装载回来重新执行。

网卡表是空的或少了几块，就改“IPv4 前缀过滤”（默认只列 `192.168.`，多个用逗号分隔），
或清空该框列出全部网口，再点“连接”——不必回去改 `config.json`。
连上了却提示**辅测机无对应网卡**，就是这个前缀把对端的网卡全滤掉了。
插拔网线、改完 IP 之后用“本机”或“辅测机”页上的“重新扫描”，不必整页刷新。辅测机页修改前缀后，重新扫描使用当前输入。

控制台只监听本机回环地址，不会被局域网上的其他机器访问到。“测试计划”页的“导出项目”
可以把整份计划存成 `cpe-ui-project.json` 传阅（不含任何口令）。

## 使用（命令行问答式）

习惯命令行、或者要跑既有配置文件时用这条：

1. 辅测机同样先双击 `start_agent.bat`。
2. 主控机双击 `start_master_select_config.bat`，选择对应网口配置，再输入辅测机 IP。
3. 交互菜单中选择 iperf3、ctsTraffic、两者对比、Ping 或全部；确认任务清单后开始。
4. 测试结束后，HTML 报告、主控日志和全部附件会保存在主控机当前目录下同一个 `runs/run_<时间>_<进程号>/` 目录中。

也可直接运行 `start_master.bat configs\config-sgmii.json`，把文件名替换为
`config-wifi5g.json`、`config-10gusb.json` 或 `config-all-common.json`。

两条路径产出的报告完全一样：控制台不是另一条执行链路，它只是把勾选结果写成一份
config，然后调用和命令行完全相同的执行流程。

运行时 TCP/UDP 会打印 `[灌包进度]`：`nic-rx` 是 Windows `GetIfTable2` 网卡计数器
实测接收速率，iperf3/CTS 自报速率不替代正式 NIC 吞吐口径；但单流是否真正建立仍必须
有工具自身的 rate、bytes、frame/datagram 证据。`iperf_outputs` 是为兼容旧版保留的目录名：

- `iperf_raw_*.log`：iperf3 client/server/事件和全部重试原文。
- `ctstraffic_raw_*.log`：CTS 每轮 client/server 命令、输出、解析摘要和生命周期。
- `nic_samples_*.csv`：逐样本 RX/TX 网卡计数。

## 配置说明

JSON 标准不支持注释，不能在一个 JSON 内可靠地“取消注释”来选择网口。这里使用多份具名配置：

- `config-sgmii.json`：SGMII 1G/2.5G。
- `config-wifi5g.json`：Wi-Fi 5G。
- `config-10gusb.json`：主控 10GUSB、辅测 10GETH。
- `config-all-common.json`：以上常用网口组合。
- `config-full-tcp-udp-ping.json`：**全量**。TCP + UDP + PING 一次跑全，覆盖 5 块网口
  两两组合的全部 10 对（6 跨机 + 4 同机）、A→B / B→A / 双向并发、IPv4 + IPv6。
  参数照搬一次实测：TCP `-w 64k/4m -P 10`，UDP `-b 1000m/2500m -l 14k -w 256m`，
  PING `n=180 × 32/1600/65500`。**约 210 个单元、跑一整夜（预计 11.5 小时）**，
  用之前先把 `tests[]` 里的 `NAME=` 换成你那两台的网卡名。

图形控制台还可以直接导入 `projects/cpe-ui-project-full.json`（「导入测试项目」按钮），
拿到同一套链路集合、套件、TCP/UDP 参数配置、判定门限和网口策略，不必手工勾 10 对网口；
项目文件不携带 RESUME、截图、历史结果或口令。

预置配置为了保持升级前的默认测试量，仍使用 `"kinds": ["iperf", "ping"]`。只跑 CTS：

```json
"kinds": ["ctstraffic"]
```

两种后端与 Ping 都跑：

```json
"kinds": ["iperf", "ctstraffic", "ping"]
```

如需更改网段、时长、流数或速率，复制最接近的配置再修改；JSON 内不要加入
`//`、`#` 或 `/* ... */` 注释。

### CTS 参数语义

- 配置中的 `src → dst` 始终表示数据方向。TCP 是 `src` client 发送、`dst` server 接收；UDP MediaStream 是 `src` server 发送、`dst` client 接收。程序自动处理 UDP 角色反转，报告方向不变。
- TCP 使用 `tcp_streams`，UDP 使用 `udp_streams`，缺省或为 `0` 时分别回退旧字段 `streams`。有效流数映射为 `Connections:N`；一个 CTS 进程承载 N 条连接。CTS 自动化要求所选协议的有效流数在 `1..=32`；配置文件超出范围会记录 `SETUP_ERROR / CTSTRAFFIC_ARGS_INVALID`，交互式输入则要求重输，不会静默修正。
- 历史字段 `iperf_duration` 供两个吞吐后端共用。CTS TCP 映射为 `TimeLimit:<毫秒>` 硬截止，CTS UDP 映射为 `StreamLength:<秒>`。CTS 自动化只接受 `1..=86400` 秒；配置文件中的 `duration=0` 不是无限，也不会被静默夹为 1 秒，而是记录 `SETUP_ERROR / CTSTRAFFIC_ARGS_INVALID`；交互式输入会要求重输。无限测试只能手工运行原生命令并手工停止。
- `tcp_windows` 对 CTS 是 Winsock socket buffer；`udp_profiles[].window` 对 iperf3 生成 `-w`，对 CTS 映射为实际发送/接收方向的 `SendBufValue`/`RecvBufValue`。它们不是 TCP 拥塞窗口；非法尺寸会记录 `SETUP_ERROR / CTSTRAFFIC_ARGS_INVALID`。
- UDP `bandwidth` 必须完整匹配十进制数值加可选 `k/m/g` 或 `kbps/mbps/gbps`；`2.8G` 与 `2.8Gbps` 都规范化为 `2800000000 bit/s`。尾随垃圾、科学计数和混合后缀不会再透传后端。CTS UDP 的速率按每条连接生效，总提供速率约为“每流带宽 × `udp_streams`”。
- `length` 的 `k/m/g` 使用 1024 进制；`14k` 等于 14336 字节。iperf3 保留原生 `-l 14k`，CTS 映射为 `DatagramByteSize:14336` 且不得大于 65507 字节。14 KiB 超过常见 1500 字节 MTU，会产生 IP 分片。
- 默认 `ctstraffic.udp_frame_rate=100`、`udp_buffer_depth_secs=1`。这是 MediaStream 模型，不等同于 iperf3 UDP flood；两种后端的数值不应当作完全相同语义的互换结果。
- CTS 接收端 NIC 统计只计算 `Connected`、有效 `Traffic` 与 `Ended` 事件可以证明的数据窗口，不计 monitor RPC、进程启动、握手、状态轮询和清理。不会用 `Total Time`、正常退出或疑似缓冲输出补窗口，也不会在无样本时回退全生命周期平均值。证据不足时返回 `NOT_EVALUATED / CTSTRAFFIC_EFFECTIVE_WINDOW_SHORT`；monitor 启动、停止、无样本和窗口内采样错误分别使用 `CTSTRAFFIC_MONITOR_*` 原因码。
- CTS 不使用 iperf3 的逐进程多流、5 秒 P10 与分阶段 `discover` 实现，但两者共享下面的 UDP 单流硬门槛和安全清理原则。

UDP socket buffer 示例：

```json
{"bandwidth": "500m", "length": "1400", "window": "1m"}
```

`window` 可使用 `64k`、`1m`、`1.5m` 等；省略时保持旧配置行为。

iperf3 UDP 单流和 CTS UDP `Connections:1` 都是每方向独立的硬连通门槛。单向 1 流，或
双向 AB、BA 每方向各 1 流时，每个方向总尝试数为 `max(flow_retries + 1, 3)`；双向两腿
各自拥有完整预算并行执行。每轮都必须完整启动 server/client，并确认停止和清理成功后
才能复用端口。

判断灌通只认所选工具自身的 rate、bytes、frame/datagram 等输出；NIC 背景流量不能补成
成功，NIC 只验证已建立流的目标吞吐。全部安全尝试仍无工具测量时，iperf3 记录
`RATE_FAIL / SINGLE_UDP_STREAM_FAILED`，CTS 记录
`RATE_FAIL / CTSTRAFFIC_SINGLE_UDP_STREAM_FAILED`，不会降级为“活跃流不足/未评估”。
平台不支持、缺工具、非法参数、尚无测量时的 server/client 生命周期、显式取消或清理未确认仍报告
`SETUP_ERROR`。一旦已有 CTS 工具测量，server 在显式停止前异常退出或超时会记录
`RATE_FAIL / CTSTRAFFIC_RUNTIME_ERRORS`，并按真实运行错误、UDP 丢包/丢帧和目标速率判定，不会靠继续重试掩盖结果。

## 前置检查和故障诊断

主控会分别检查两个吞吐后端。CTS 会确认主控真实 Windows major 版本不低于 10，且 agent 只在自身同样通过真实版本检查时才声明 `ctstraffic_v1`
能力，然后检查两端二进制；版本无法确认时 fail-closed。任一项不满足时，仅 CTS 单元记录
`SETUP_ERROR / CTSTRAFFIC_PREFLIGHT_FAILED`。程序不会静默改跑 iperf3，已选的 iperf3/Ping 仍继续。

本地单元测试和 CI 可以验证参数、生命周期、报告与发布包，但不能代替真实网卡、驱动、防火墙和 CPE 环境。发布后仍建议在两台真实 Windows 10+ 设备上完成 CTS TCP/UDP 双机数据流验收。

常规子网 Ping 默认覆盖 32、1600、65500 字节负载。若本轮所有 iperf3/CTS 单元都没有
有效速率测量，主控会继续或追加短 Ping 和本机网关诊断。无网关时报告
`GATEWAY_NOT_FOUND`，不会伪装成 100% 丢包；当前版本不抓 PCAP。

## 常见问题

ADB 内环测速在控制台左侧“内环测试”中配置：主控连接 ADB，其他网口所在电脑运行同版本 `cpe_test agent`，在内环页单独添加辅测机、选择电脑和网卡。**辅测机是可选的**——只挂在本机的网口能独立跑完一轮，没被引用的辅测机就算离线也不阻断。网口用一张勾选表格管理：勾选决定这一轮跑不跑（取消勾选保留参数，和删除是两回事），上移/下移决定执行顺序，可批量改板侧 LAN、统计接口、测量策略和门限。方向分上行、下行和双向并发；勾“上行+下行”是两个单向单元，勾“双向并发”是一个两条腿同时跑的单元，两次顺序单向不算双向。开跑前的“计划预览”会说明本轮有几个单元、几条腿、每条腿的接收端和判定依据；执行区可选择“仅测试内环”或“子网 → 内环（RESUME）”，后者按顺序执行两段并分别跳过各自历史中的 PASS。使用“导入内环配置 / 导出内环配置”保存 `cpe-inner-project.json`（当前 `version: 2`，旧的 v1 文件导入时自动升级），与子网项目分开；辅测机地址最多 256 字节、令牌最多 4096 字节且不导出。Windows 示例 `inner.example.json` 需按实际电脑地址修改。也可运行 `cpe_test.exe inner --config inner.example.json --probe`，去掉 `--probe` 后按计划逐个单元测。需另备 Android Platform Tools 的 adb 与板侧 iperf3。两类测试依次运行，配置、停止状态及报告独立；内环报告位于 `inner_runs`（页面下方“内环历史”可下载或恢复重跑，默认开启内环 RESUME），组合场景记录位于 `scenarios`，子网仍为 `runs`。内环提供 HTML/JSON，暂不提供 Excel；子网报告包含 Excel。运行中下载可能落后于界面进度，收尾后为完整结果，历史记录会标明是否收尾。完整说明见《使用说明》的“ADB 内环测速”。

内环双向结果只采用共同测量窗口；无重叠时不判通过。工具的全程 receiver 汇总不能代替部分重叠区间的速率。板侧计数不可用时，严格网卡策略会阻止执行，工具或优先网卡策略可继续并记录计数失败原因；没有可信 receiver 汇总仍为 NOT_EVALUATED。

新建内环网口默认板侧 LAN 地址为 `192.168.0.1`、板侧桥接口为 `br0`。上行看板侧桥 RX，下行看所选 PC 网口 RX，双向分别记录这两处。RNDIS、网线、Wi-Fi 共用这个口径，无需配置板侧成员口。桥名称变化可在网口详情中手动修改，清空表示按 LAN 地址归属自动识别；选择电脑网卡不会覆盖手填的板侧目标。修改随草稿和导出配置保存。批量编辑留空表示不修改。

内环上下行均使用普通 client/server 命令：上行 PC → CPE，下行 CPE → PC。下行会在所选 PC 的被测 IPv4 上监听 iperf3 端口，请允许该 PC 的防火墙接收入站测试连接（UDP 测试同时需要 TCP 控制连接与 UDP 数据）。主控不自动更改防火墙。接收计数仍为上行 br0 RX、下行 PC 网口 RX。
