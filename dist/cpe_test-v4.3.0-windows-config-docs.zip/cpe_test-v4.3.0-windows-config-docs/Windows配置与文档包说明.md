# cpe_test v4.3.0 Windows 配置与文档包

仓库中的 `cpe_test-v4.3.0-windows-config-docs.zip` 是便于从 Git 直接下载的
Windows 配置、说明文档和启动脚本资料包。包内文件由仓库当前版本生成，并由 CI
逐文件与源码副本比对，避免配置或文档过期。

这个资料包**不包含可执行程序或吞吐工具**：

- 不包含 `cpe_test.exe`；请从 GitHub Release 下载正式
  `cpe_test-v4.3.0-windows-x86_64.zip`，或自行编译。
- 不包含 `ctsTraffic.exe`；正式 Windows Release ZIP 会捆绑固定并校验过的
  Microsoft ctsTraffic 2.0.4.0 x64。
- 不包含 `iperf3.exe` 及其 DLL；需要 iperf3 测试时，请放入完整的 Windows
  iperf3 发行包。

## 包内内容

- Windows 快速开始、完整 README、使用说明、NIC 说明和 UDP 验收场景。
- `config.minimal.json`（最小可用：首次跑通只需改 `agent_host`、`agent_token`、
  `iperf.duration` 三项，其余走内置默认值）。
- `config.example.json`（完整字段面）与 `configs/` 下四份可直接选择的具名配置。
- `start_ui.bat`（图形控制台）、`start_agent.bat`、`start_master.bat`、`start_master_select_config.bat`。
- iperf3/ctsTraffic 放置说明、MIT 许可证和第三方声明。

## v4.3.0 行为要点

- 新增图形控制台 `cpe_test ui`（`start_ui.bat`）：浏览器里逐网口配置 RX 门限/发送端 UDP `-b`，勾选网口组合、方向、协议和 IP 版本，并扫描 TCP `-w` / `-P`、UDP `-b` 多档参数；支持预览、下载 config、实时进度、优雅结束和打开报告。它仍调用和命令行相同的执行流程，不是第二条执行链路。
- 修复双向 UDP 一条腿失败会连坐判废另一条腿的有效数据：判定窗口改为逐腿计算，「两条腿有没有真正并发」单独作为事实写进原因。
- 修复 UDP 丢包率把接近满丢包报成 0.000%：只认 `receiver` 汇总行、用 `lost/total` 计数算，取不到报「未知」而不是 0。
- 修复 iperf3 收尾握手失败会丢掉已测到的网卡数据：有效窗口攒够时判定完全交回接收端网卡口径。
- 新增计数器停滞检测 `COUNTER_STALLED`：样本采齐、覆盖率 100%，但字节计数长时间不动。
- UDP `-b` 按 `min(发送口, 接收口)` 裁剪；在 `link_profiles` 里明确配过的链路不裁。
- WiFi 负载上限不再跟随会来回跳的协商速率，改用 `wifi_payload_ceiling_mbps`（默认 2800）。
- 新增两层链路策略 `link_profiles`：`by_role` 角色兜底 + `by_nic` 单口覆盖，门限与带宽都按方向独立。
- 每个测试单元开始前重新拉取双端网卡，变更记 `拓扑变更`，网卡消失判 `NIC_DISAPPEARED`。
- 报告新增执行序号（与控制台 `[N/总数]` 一致）和运行健康横幅。

## v4.2.7 行为要点

- 修复 TCP / ctsTraffic 会把「网卡采样不可信」误判成「CPE 不达标」：采样可信度现在一律先于任何性能结论。
- TCP / ctsTraffic 补上发送端网卡采样；有明确目标时 RX/TX 双侧的采样与 5 秒滚动覆盖率都要达标，PASS 条件变严。
- TCP / CTS 的 resume identity 升版，旧版缓存的 PASS 不会被 `--resume` 复用。
- 报告新增判定证据：判定窗口区间、已扣除的背景速率、5 秒滚动窗口覆盖率；传输列区分 iperf3 与 ctsTraffic，两者 UDP 语义不等价、不应直接互比。
- 原因码分层：报告正文直接说明下一步该做什么（环境问题 / 配置问题 / 设备确实不达标），原有原因码保留为小字。
- 新增 `config.minimal.json`，首次跑通只需改三项。

## v4.2.6 行为要点

- 网卡监控与控制台/CSV 时间戳带完整日期（如 2026-08-17 12:00:01），跨天监控也能对上问题发生的时刻。
- 双向 UDP 的 attempt/retry 日志带 [ab]/[ba] 方向前缀，master.log 里两腿重试记录可区分。
- iperf 有效窗口优先采用行内区间（即使短于要求时长也按实际裁剪），不再回退到 client 进程寿命，避免短测量被补成完整窗口并把启动爬升计入接收端平均。
- 报告概览新增截图列（主控/辅测缩略图并排、点击开原图，未采集时整列不渲染）；单条流明细显示流量工具自报速率，网卡列注明按方向统计；双向不再显示 AB+BA 接收速率合计。

- HTML 报告的 Ping 概览显示丢包率以及 RTT 最小/平均/最大值；`PING_OK` 和 `RESUME_FRESH_PASS` 会解释通过与跳过原因。
- 逐行诊断保留主控/辅测截图、实际灌包命令、raw log、NIC CSV 和内嵌原始输出；移动端报告也可展开查看。
- 双向 TCP/UDP 按 AB、BA 分别汇总接收端 RX 平均、RX-P10 和目标，并显示 AB + BA RX 平均合计；UDP 并发由独立 client 实现，不使用 `-P`。
- TCP 双向执行行显示两个方向，UDP 双向区分流明细与方向组合计，避免把执行明细误报成多个测试任务。
- TCP 与 UDP 并发流数可分别通过 `tcp_streams`、`udp_streams` 控制；缺省或为 `0` 时分别回退旧字段 `streams`，交互菜单按已选协议分别询问。
- `2.8G` 与 `2.8Gbps` 均严格规范化为 `2800000000 bit/s`；非法尾随内容不再交给 iperf3/CTS 宽松解释。`14k` 按 1024 进制等于 14336 字节，超过常见 MTU 时会产生 IP 分片。
- CTS 接收端 NIC 速率只统计真实事件证明的数据窗口，不再把启动、握手、轮询和清理空窗计入平均值，也不再用全生命周期均值回退。有效窗口证据不足时返回 `NOT_EVALUATED / CTSTRAFFIC_EFFECTIVE_WINDOW_SHORT`，避免误报低速或 `RATE_FAIL`。
- monitor 启动、停止、无样本和窗口内采样错误均有明确 `CTSTRAFFIC_MONITOR_*` 原因码；CTS resume 统计语义升级后不会复用旧版缓存结果。
- CI 和本地测试不能代替真实网卡、驱动、防火墙与 CPE 环境；发布后仍建议使用两台真实 Windows 10+ 设备完成 CTS TCP/UDP 双机数据流验收。

使用时，优先下载正式 Windows Release ZIP；如果只需要更新配置、文档或启动脚本，
可以单独下载本资料包并按需覆盖对应文件。主控和辅测机的 `cpe_test.exe` 必须来自同一
Release。
