# CPE 子网测试工具

> 两台电脑间自动化 ping + iperf3 / Microsoft ctsTraffic 灌包测试，零 Python/零 PowerShell

## v4.4.0

- **双向门限（按配对）**：测试矩阵里每一对网口多两个输入框——`双向门限 A→B / B→A`，
  只在勾了「双向」时生效，留空沿用「网口与策略」里的 RX 门限。
  半双工介质（Wi-Fi、部分 USB 网卡）双向同时灌包时两个方向抢同一段介质时间，
  每个方向拿到的只有单向的一部分；拿单向门限去卡双向必然判 `RATE_FAIL`，
  而那是配置出来的失败、不是测出来的。典型写法：单向 2000，双向两格各填 1000。
  **按配对而不是按网卡**：同一块 RNDIS 口，和 Wi-Fi 组双向、和 SGMII 组双向，
  能收到的速率完全不是一个量级，挂在网卡上只能填一个数、必然有一组是错的。
  两个方向分开填是因为半双工链路的两个方向本来就能差很远。只收绝对 Mbps——
  百分比要按单块网卡的协商速率换算，跟「两块口凑在一起并发时能跑多少」不成比例。
  配置文件里对应 `rate_targets_bidir_mbps`（`universal_params` 与每个 test 都可写）。
  填了却没勾「双向」会当场报错，不会静默忽略。
- **控制台能被 Ctrl+C 关掉了**：此前 `run_master()` 会装上一个「只置标志、不退进程」的
  取消处理器且**永不撤销**，而控制台的取请求循环从不查那个标志——于是在 macOS/Linux 上
  跑过一轮测试之后 Ctrl+C 就再也关不掉控制台，只能另开终端 kill。现在控制台自己装处理器，
  空闲时按一次即退出；测试正在跑时先让它优雅收尾出报告，收完再退。
- **辅测机上的 UI 监控不再可能挂两小时**：`/monitor/status` 现在会刷新租约，
  租约从「最后一次被问」起算而不是从启动起算，UI 侧的租约同时从 7200 秒降到 180 秒。
  控制台被 kill 之后没人再来问，辅测机一个租约周期内自己回收。
  监控的错误列表也封了顶（保留最近 200 条 + 准确计数）：网卡被拔掉时每一拍都会推一条，
  长跑能攒出几万条一模一样的字符串。
- **修 iperf3 Byte 单位按 1000 进制解析**：iperf3 的 bit 单位按 1000 进位、Byte 单位按
  1024 进位（实测：100 Mbits/sec 打印成 `11.9 MBytes/sec`）。解析器两边都按 1000 算，
  `-f M` 下会低报 4.6%、`-f G` 低报 7.0%。今天下发的固定是 `-f m` 所以走不到，
  但解析器不该依赖调用方的自觉。
- **客户端给响应体加了上限**：`Content-Length` 出来的 `usize` 此前被直接拿去
  `Vec::resize`，对端说多大就申请多大。辅测机 IP 是人手敲的，敲到别的服务上时
  表现是进程被 OOM 掉而不是一句可读的错误。现在和 agent 的 `MAX_BODY` 一样封在 100MB，
  chunked 走累计预算，另加一个总时限（`set_read_timeout` 管的只是单次读）。
  连接也不再只试解析出来的第一个地址——主机名同时有 AAAA 和 A 记录时会逐个试。
- **`RX_DROPOUT` 补进两张消费侧的表**：v4.3.1 新增的这个原因码此前既没有处置建议、
  也没有「展示指标是否支持这条判定」的交叉核对，而它取代的 `RX_UNSTABLE` 两处都有。
  同时补了 `RX_P10_BELOW_TARGET`、`NIC_DISAPPEARED`、`NO_VALID_MEASUREMENT`、
  `IPERF_SUMMARY_LOST` 的建议，并加了一条测试：把 `rate_window.rs` 在编译期读进来，
  逐个核对里面的原因码都有归属——漏登记不再是「永远没有信号」。
- **删掉已经不产出的 `UNSTABLE`**：v4.3.1 起掉速统一归 `RATE_FAIL`，但报告概览里
  那格恒为 0 的 `UNSTABLE` 统计块还在，会被读成「这轮没有不稳定的」。
- **状态页说缺 iperf3、补上文件后能自己变绿**：查找结果此前是进程级永久缓存，
  补完文件只能重启 agent，而页面上没有任何地方提示要重启。现在带 30 秒 TTL。
- **辅测机状态页也上了并发**：`/api/status` 要重扫网卡（Windows 上 1–2 秒），
  单线程期间每 1.5 秒一次的活动轮询全在排队。主控控制台早就为同一个理由加了线程池。
- **非中英文 Windows 上不再扫不到网卡**：`ipconfig /all` 的适配器标题行措辞跟界面语言走
  （德语 `Ethernet-Adapter`、日语 `アダプター`、法语 `Carte`），此前只认中文「适配器 」
  和英文「 adapter 」，而扫描主循环挂在这份结果上。现在补了德语写法，并用
  `GetIfTable2` 给的接口别名做语言无关的兜底；真的一条都认不出来时会打印诊断而不是静默返回空表。
- **控制台日志框封顶 4000 行**：服务端镜像早就封顶了，浏览器这边一行不丢——
  一次 120 单元的运行会打出三万多行，`textContent +=` 的累计拷贝量是行数的平方级。
- **监控曲线的横轴改成时间**：此前用的是数组下标，采样停顿会被画成一段连续等距的线，
  看不出中间断了；而这条曲线的用途恰恰是发现掉速和断流。同时补了时间刻度，
  并把前端保留点数、页面文案、曲线绘制窗口统一成同一个数（7200）——
  此前是 3600 / 7200 / 600 三个数，读数里的峰值能高过图上最高的那条网格线。
- **辅测机侧采样间隔上限跟着监控端走**：agent 自己把间隔夹在 200–5000ms，
  而界面允许填到 60000——选 10 秒会变成「对面按 5 秒采、这边按 10 秒只取最后一个样本」，
  一半样本无声丢掉，同样选 10 秒监控本机却是对的。
- **报告里内嵌的原始输出掐头去尾**：同一份文本已经作为 `raw_log` 单独落盘并给了链接，
  内嵌那份是给「点开就看」用的。保留头尾各一半，因为汇总行在最后。
- **杂项**：日志镜像换 `VecDeque`（封顶后每行少搬 4000 个 `String`）；
  「打开报告」的子进程会被回收（Unix 上此前每点一次留一个僵尸）；
  `http_client.rs` 里约 580 行故障注入脚手架关进 `#[cfg(test)]`（此前靠 12 处
  `#[allow(dead_code)]` 盖着，跟着生产构建一起编译）；
  `AgentResourceInventory` 补上第一条直接测试（此前并发/故障用例全打在手写的测试替身上）。
- 单元测试 417 → 452。

- **Wi-Fi 2.4G 内置上限改为 574**：`wifi_24g_payload_ceiling_mbps` 默认从 300 改成 574
  （802.11ax 2SS 在 2.4GHz 的 PHY 峰值）。这是一条**挡离谱值**的线而不是贴近可用载荷的线：
  实际载荷明显低于 574，所以它不会裁掉正常量级的灌包，只拦住把 5G 档的 `-b 2.6G` 原样
  丢给 2.4G 口这种配置。要按某条链路的实际能力裁，仍然在 `link_profiles` 里给那块网卡
  明确配 `-b`——明确配过的链路不受本上限影响。
- **控制台加 resume 开关**：`resume` 此前是配置文件里唯一「会悄悄生效、界面上却既看不见
  也关不掉」的项。现在和「按链路上限裁剪」同一套语义：界面上的勾选是唯一来源。
  「预览任务」会直接查同一个结果库，把会被跳过的单元标成 `[resume 跳过]`，并把它们
  从预计耗时里扣掉——否则勾了 resume 却看到满满一屏计划，人会以为没生效。
- **ping 进测试矩阵**：协议列多一个 `PING`（默认不勾），执行区新增 ping 次数与包长输入。
  走的仍是同一个 `run_master()`，不新开执行路由。两个输入不是可选的：不填就回落到
  `ping.count=100 × 三档包长`，每个配对每个方向平白多出三个各一百多秒的单元。
- **新增监控标签页**：控制台顶部分「测试 / 监控」。监控可选本机或辅测机的任一网卡，
  实时画 RX/TX 曲线，**和测试并发**（辅测机侧用独立 owner_id，不会被测试收尾的
  owner 清理误杀）。页面静默 90 秒后采样线程自行收摊，关掉标签页不会留下常驻线程或
  agent 上的 monitor 资源。长期留存曲线仍请用 `cpe_test monitor --csv`。
- **控制台打开即可用**：新增只读的 `GET /api/local` 与「本机」区，显示本机主机名、
  iperf3 版本和网卡表——**不需要先连上辅测机**。此前打开控制台只有一个空的 IP 输入框，
  而那个 IP 要去对面机器的状态页上抄。同时 `api_bootstrap` 现在会回落读 `.cpe_last_agent`
  预填 IP：命令行主控一直在读写它，控制台此前只写不读。
- **两个 Web UI 可改绑定地址**：新增 `--ui-bind`。主控控制台放到非回环地址时**必须**
  同时给 `--ui-token`，否则拒绝启动——它能改配置、能发起测试、能下载 config，
  而此前完全没有认证（只有一个防跨站的 `X-CPE-Console` 头，curl 可绕过）。
  口令随启动打印的地址以 `?token=` 传入，页面加载后会把它从地址栏抹掉、转存进
  `sessionStorage`（跟着标签页走，关掉即没）——否则刷新一次就再也进不来，只能回
  终端翻启动日志。也接受 `X-CPE-Token` 与 `Authorization: Bearer`；比较是定长时间的。
  两处没有被这一步覆盖，需要知道：带 token 的那个 URL 会进浏览器的**持久化历史库**；
  Windows 上自动打开浏览器走的是 `cmd /C start "" <url>`，token 会出现在 `cmd.exe`
  的命令行里。介意就用 `CPE_UI_TOKEN` 环境变量并手动粘地址打开。
  两处 `--ui-bind` 都直接收裸 IPv6（`::1` / `::`），不用自己补方括号。它**有意不进 config.json**——
  控制台自己就提供「下载 config.json」。辅测机状态页全是只读 GET，放开只打印提示。
  `cpe_test ui` 另补上 `--token`（与 agent 相同的共享令牌），两个 token 都支持
  环境变量（`CPE_AGENT_TOKEN` / `CPE_UI_TOKEN`），避免留在 shell 历史和 `ps` 里。
- **辅测机状态页「重新扫描」现在有反馈**：此前点了之后按钮不变、表格重绘成一模一样的
  内容，成功和没反应在屏幕上长得一样（Windows 上还要等 ipconfig/netsh 一两秒）。
  现在按钮置灰 + 「扫描中…」，回来后写明扫到几块网卡和时间。失败也不再覆盖「运行状态」
  那一行——那行归实时活动管，被覆盖后要等 60 秒兜底轮询才恢复。
- **两个 UI 去掉 ctsTraffic 信息**：状态页那条 fact 是没装 cts 的 Windows agent 上唯一
  常驻的橙色告警。事件表里的 `/ctstraffic/*` 中文标签保留（删了会显示裸路径），
  后端能力一点不动。
- **修 URL 解码在畸形转义上会 panic**：`%` 后面跟多字节字符时（如 `%中`），按 `&str`
  下标切那两位十六进制会切在字符中间直接 panic，而这段输入来自网络。
- 单元测试 406 → 417。

## v4.3.1

- **接收速率判定改为「每个 5 秒窗口都要达标」**：平均和 P10 都达标、但判定窗口内有任意一个
  完整 5 秒滚动窗口掉到门限以下时，判 `RATE_FAIL / RX_DROPOUT`，并写明掉了几个窗口、最低多少、
  最长连续多少秒、从第几秒起；掉到接近 0 时说「断流」而非「掉坑」。一次 5 秒断流在 175 秒的
  测试里只占 3%，P10 完全看不见它，但那几秒业务就是断的。TCP 与 UDP 两条判定链共用同一个
  `rx_dropout` 谓词。`UNSTABLE` 不再产出，掉速统一归 `RATE_FAIL`，靠原因码区分严重程度。
- **Wi-Fi 2.4G 不再借用 5G 的负载上限**：此前 `WIFI` / `WIFI2.4G` / `WIFI5G` / `WIFI6G` 共用
  `wifi_payload_ceiling_mbps`（2800），等于对 2.4G 口完全不裁剪——2.4GHz 只有 3 个不重叠信道、
  最多 40MHz，802.11ax 2SS 的 PHY 峰值也就 574Mbps。新增 `wifi_24g_payload_ceiling_mbps`
  （默认 300）。频段没识别出来的 `WIFI` 仍按 5G 档，避免误裁真正的 5G 口。
- **修复控制台生成重复测试单元**：`-b` 是否被按网口覆盖此前按整对判断，于是「ab 方向被发送端
  钉死、ba 方向要扫档位」这种常见组合会把那个 ab 单元原样复制 N 份（3 档 × 180s = 6 分钟白跑，
  报告里还多出两行看着像 bug 的重复项）。改为逐方向判断。
- **新增辅测机状态页**：`cpe_test agent` 随进程在 `127.0.0.1:28802` 起一个只读页面（`--ui-port`
  可改、`--no-ui` 可关），显示运行状态、本机网卡（主控要填的 IP 从这里挑，主控连上后标出用的是
  哪一块）和实时活动——把几万行请求日志折叠成十来行「启动 iperf3 服务端」「查询网卡采样 ×30」，
  主控 token 填错会显示成红色失败记录。绑不上端口只提示，不影响 agent 本身。
- **控制台可编辑的参数补齐**：新增 UDP `-l` 与 UDP `-w` 多档输入（与 `-b` 取组合，留空则完全
  不下发该参数）；「网口与策略」新增按网口的 UDP `-l`，只作用于该网卡作发送端的那条腿；
  RX 门限支持 `90%` 写法（按该网卡协商速率换算，算式出现在计划提示里）；新增「按链路上限裁剪
  UDP -b」开关，控制台默认**不裁剪**；新增「网段前缀」输入框（默认只列 `192.168.`，10.x/172.x
  实验网此前只能回去手改 config.json）。
- **测试矩阵加整列开关**：方向 / 协议 / IP 三列表头各有一排勾选框，勾一下整列全开、再勾一下
  整列全关；「全选」连双向和 IPv6 一起勾上。此前这三列只能逐行点，且全选后无法取消。
- **去重**：报告里的 `-w` 尺寸解析改用下发命令同一个解析器（自带的简化版在 `2.5m` / `4mb` 上
  解析失败，校验放行、命令照发，只有报告里的估算无声消失）；控制台的网卡匹配规则改为复用
  `rate::nic_profile_matches`，不再各写一份。
- 单元测试 379 → 406。

## v4.3.0

- **图形控制台**：`cpe_test ui`（双击运行的默认入口，Windows 包里是 `start_ui.bat`）在
  `127.0.0.1:28800` 起一个本地页面——填辅测机 IP 连接、按网口填写 RX 门限和 UDP `-b`、
  勾选网口组合与方向，并分别扫描 TCP `-w` / `-P` 和 UDP `-b` 多档参数；开始后同页看实时进度，
  可优雅结束并生成部分报告、下载 config 或打开最终报告。**它不是第二条执行链路**：
  「开始测试」把勾选结果写成一份 config，再调用和命令行完全相同的 `run_master()`，
  所以 `--auto`、`--resume` 和既有配置文件的行为一个都没变。零新依赖（复用 tiny_http）。
- **修复双向 UDP 一条腿失败会把另一条腿的有效数据一起判废**：判定窗口原先是全单元共用一个
  （各腿采样区间求交集、且要求每个时刻每条腿都有足够活跃流），于是 ba 腿没跑通时，
  ab 腿哪怕整整三分钟满速也会被写成 `RX均值=- 覆盖率=0.0% NOT_EVALUATED`。
  窗口改为逐腿计算；「两条腿有没有真正并发」单独作为一个事实写进判定原因，不再吃掉测量结果。
- **修复 UDP 丢包率会把接近满丢包报成 0.000%**：解析用的正则匹配不了 iperf3 满丢包时打印的
  科学计数法 `(1e+02%)`，又在整段文本上取最后一次匹配（常落到 server 尾部 `0/0 (0%)` 的
  收尾残帧）。现在只认 `receiver` 汇总行、直接用 `lost/total` 计数算，取不到就报「未知」而不是 0。
- **修复 iperf3 收尾握手失败会丢掉已经测到的网卡数据**：`unable to send control message …
  Connection reset by peer` 这类错误发生在灌包**结束之后**的结果交换阶段，此前整行判
  `SETUP_ERROR / 接收=0`。现在只要有效窗口已经攒够，判定就完全交回接收端网卡口径——
  RX 低于目标仍是 `RATE_FAIL`，RX 为 0 仍是 `NOT_EVALUATED`，只是原因里注明工具自报不可用、
  执行状态保持 `ERROR`。
- **新增计数器停滞检测**：样本采齐、`valid` 全是 true、覆盖率 100%，但字节计数长时间纹丝不动——
  这是与采样覆盖率**正交**的一种不可信，光看覆盖率永远发现不了。新增 `stalled_ratio` 指标和
  `COUNTER_STALLED` 原因码，TCP 与 UDP 两条判定链共用同一判据。
- **UDP `-b` 按整条路径能力裁剪**：此前 `limit_udp_by_link_speed` 只裁流数、从不碰带宽，
  于是 1Gbps 收端也会被灌 2.6G，丢包是配置出来的而不是测出来的。现在按
  `min(发送口, 接收口)` 裁剪，裁剪动作写进任务标签和报表；在 `link_profiles` 里
  为某条链路明确配过带宽的**不裁**——那是操作者的判断，安全网不该推翻它。
- **WiFi 负载上限不再跟随协商速率**：协商值是 PHY 速率，同一块 Wi-Fi 7 网卡会在一轮测试里
  于 2402 / 2882 之间来回跳，跟着它裁 `-b` 会让相邻两个单元的灌包强度都不一样。
  新增 `wifi_payload_ceiling_mbps`（默认 2800，恰好容得下常用的 `-b 2.6G`）供 5G/6G 使用；
  2.4G 单列 `wifi_24g_payload_ceiling_mbps`（默认 300）——2.4GHz 只有 3 个不重叠信道、
  最多 40MHz，802.11ax 2SS 的 PHY 峰值也就 574Mbps，和 5G 共用 2800 等于对 2.4G 口完全不裁剪。
  频段没识别出来的 `WIFI` 按 5G 档：落到那里多半是 macOS/Linux 扫不到频段，压到 2.4G 档会误裁真正的 5G 口。
- **接收速率判定改为「每个 5 秒窗口都要达标」**：平均和 P10 都达标、但中间有任意一个完整
  5 秒滚动窗口掉到门限以下时，判 `RATE_FAIL / RX_DROPOUT`，报告里写明掉了几个窗口、最低多少、
  最长连续多少秒；掉到接近 0 时说「断流」而不是「掉坑」。一次 5 秒断流在 175 秒的测试里只占 3%，
  P10 完全看不见它，但那几秒钟业务就是断的。`UNSTABLE` 不再产出，掉速统一归 `RATE_FAIL`。
- **新增两层链路策略 `link_profiles`**：`by_role` 按角色配对给默认值（配对串左边是 A、
  右边是 B，`ab`/`ba` 相对这个顺序），`by_nic` 按单块网卡覆盖。RX 门限和 UDP 带宽都按方向
  独立解析——同一条链路两个方向能力可以差 100 倍，用一个门限卡两边没有物理意义。
- **每个测试单元开始前重新拉取双端网卡**：此前网卡快照在开跑时取一次，之后一路按值拷进每个
  任务，一轮近 7 小时全程不更新。现在逐单元比对 IP / 接口索引 / 协商速率，变了就改任务并记
  `拓扑变更`，网卡消失判 `SETUP_ERROR / NIC_DISAPPEARED` 而不是对着不存在的接口起采样。
- **报告新增执行序号**：概览首列和明细区都带 `#N`，与控制台打印的 `[N/总数]` 一致。
  同名标题在上百个单元里会重复十几次，此前拿控制台记录去报告里根本定位不到对应项。
- **报告新增运行健康横幅**：链路中途失联这类横跨一整段单元的事实在最顶上单独说一次，
  逐行看永远拼不出来。连续零测量的灌包单元会告警；`abort_after_dead_traffic_units`
  可选开启自动中止（默认 0 只告警——「连续零测量」区分不了「设备掉线」和「其中一对网口本来
  就不通」，自动中止会把别的配对一起砍掉）。
- **`-w` 过大时给出提示与在途缓冲估算**：`-w 256m -P 10` 等于 2.56GB 发送缓冲，会让
  「工具自报发送」恒定虚高约 119Mbps（那些字节可能一个都没上线）。现在超过「链路 2 秒流量」
  时提示，报告诊断面板给出 `估算在途缓冲`，让这个差值可核对。参数本身不改写。
- 单元测试 337 → 379。

## v4.2.7

- **修复 TCP / ctsTraffic 会把「采样不可信」误判成「CPE 不达标」**：这两条路径原先先比对 RX 目标、再检查 5 秒滚动窗口覆盖率，于是「网卡计数器中断后恢复」这类环境异常会被写成 `RATE_FAIL / RX_BELOW_TARGET`。现在采样可信度一律先于任何性能结论，与 UDP 路径顺序一致。
- **TCP / ctsTraffic 补上发送端网卡采样**：此前只采接收端，验收要求的「有目标时 RX/TX 任一侧滚动覆盖率低于 95% 均为 NOT_EVALUATED」在这两条路径上并未生效，报告里的源网卡 TX 指标也一直是空的。现在两端各起一个采样器（同一块网卡时复用），PASS 条件相应变严。
- **TCP / CTS 的 resume identity 升版**（`iperf_tcp_v3`、`ctstraffic_v4`）：PASS 条件变严，旧版缓存的 PASS 不能再被 `--resume` 复用，否则会用旧语义的结论冒充新验收。
- **判定语义收敛到单一实现**：新增 `verdict` 模块统一 `Verdict`、原因码优先级与单元聚合，执行端与报告端不再各写一份（此前两份实现顺序不一致，先后导致过两个静默错判）；并加了源码级结构断言防止再次分叉。
- **报告新增判定证据**：每行给出判定窗口区间（可直接对到网卡逐样本 CSV 的 `elapsed_ms`）、已扣除的背景速率中位数、5 秒滚动窗口覆盖率；传输列区分 `iperf3 UDP` 与 `ctsTraffic UDP`，两种后端同时出现时提示其 UDP 语义不等价、不应直接互比。
- **原因码分层**：报告把「下一步该做什么」升为正文（是环境问题、配置问题，还是被测设备确实不达标），原有原因码降级为小字保留，不改动任何码本身。
- **配置**：新增 `config.minimal.json`（只需改 3 项即可跑通）；配置加载时校验会让 `settle_secs ≥ duration` 这类「静默把每个吞吐单元变成 NOT_EVALUATED」的写法直接报出来。
- **网卡样本 CSV** 头部新增 `origin_offset_ms` 与 `origin_uncertainty_half_width_ms`，共同窗口卡在边界时可判断是真够还是双机对齐误差凑够的。macOS 上报告会提示网卡采样经由 netstat 子进程、抖动高于 Windows/Linux。
- CI：ctsTraffic 二进制增加自托管镜像兜底（两条路径都过同一个 SHA-256 门槛）；单元测试 311 → 337，新增 8 个 UDP 编排层场景（U00C/U00D/U00E/U00F/U00G/U01/U02/W09）。

## v4.2.6

- 网卡监控与控制台/CSV 时间戳升级为完整日期时间（如 `2026-08-17 12:00:01`），跨天长时间监控也能直接定位问题发生的时刻。
- 双向 UDP 两腿并行时，master.log 的 attempt/retry 日志带 `[ab]`/`[ba]` 方向前缀，两条腿的重试记录不再无法区分。
- 修复 iperf 有效窗口被“补长”：iperf 行内区间是权威来源，短于要求时长也按实际裁剪，不再回退到 client 进程寿命——此前一次只测到 175 秒的短测量会被补成 180 秒完整窗口，并把启动爬升算进接收端平均。
- 报告概览新增截图列：主控/辅测截图缩略图与接收速率并排展示、点击打开原图，未采集截图时整列不渲染；单条流明细显示流量工具自报速率（工具证据，非判定口径），并注明网卡按方向统计、见组合计行。
- 双向判定不再展示“AB + BA 接收端 RX 平均合计”，避免把两个方向的接收速率相加误读成整机吞吐；无单元汇总行的旧数据也复刻执行端聚合顺序，单流 UDP 硬失败不会被另一方向的“无法评价”掩盖。
- 概览表窄屏自适应：标签可在下划线处折行，判定原因独占整行不再被列宽截断；中屏等比压缩去掉横向滚动，窄屏保留冻结前 3 列并把横向滚动条压回视口内。

## v4.2.5

- 报告测试概览补齐 Ping 丢包率与 RTT 最小/平均/最大值，并用 `PING_OK`、`RESUME_FRESH_PASS` 等原因码解释 PASS 和 SKIP；不会再把通过原因显示成“不适用”。
- 恢复逐行诊断可见性：主控/辅测截图、实际灌包命令、独立 raw log、NIC CSV 和内嵌原始输出都在报告中有明确入口，移动端也保留这些内容。
- 双向 TCP/UDP 报告按 AB、BA 分开汇总，显示各方向接收端 RX 平均、RX-P10、目标和判定，并给出 AB + BA 的 RX 平均合计；RX-P10 不做无意义相加，原因码会与展示指标交叉核对。
- 执行行计数改为测试语义：TCP 双向显示两个方向，UDP 显示流明细与方向组合计，Ping 显示 Ping 行；Windows/iperf3 UDP 并发使用独立 client，不在单条命令上追加 `-P`。
- UDP resume identity 升级到 `iperf_v4`，避免复用旧统计窗口语义下的缓存 PASS；全量测试、Clippy、格式检查和桌面/移动端报告验收均通过。

## v4.2.4

- [P1] 修复 `status()` 先复制事件、再读完成状态的竞态：done=true 的快照现在保证包含 completion 写入前推送的全部事件，主控不会因停止轮询而永久漏掉尾部 Traffic/Ended。
- [P1] start RPC 时间轴只统计成功那次调用的耗时：首次连接超时、重试成功后，远端 job 零点不再被前几次失败的重试等待整体偏移。
- [P2] 远端 monitor 零点由 start 响应的 `elapsed_ms` 做有界估计，不再用 RPC 往返中点猜测，非对称网络延迟不会再把空闲时间混入正式窗口。
- agent 控制平面加固：支持 `--token`/`agent_token` 共享令牌认证（未认证请求返回 401 且不创建任何资源）与 `--bind` 监听地址收紧；主控在 config.json 配置相同令牌即可连接。
- 报告、主控日志和 iperf3/ctsTraffic/NIC/截图附件按每次运行归档到独立的 `runs/run_<时间>_<进程号>/` 目录，报告中的缩略图仍可点击打开原图。
- CI 质量作业扩展到每个 PR/分支推送，不再只等 tag 或手工触发；文档、配置与受跟踪资料包版本统一为 4.2.4。

## v4.2.2

- TCP 与 UDP 并发流数可分别通过 `tcp_streams`、`udp_streams` 控制；缺省或为 `0` 时分别回退旧字段 `streams`，已有配置保持兼容。交互菜单会按已选协议分别询问流数。
- UDP 带宽改为严格完整解析：`2.8G` 与 `2.8Gbps` 都规范化为精确的 `2800000000 bit/s`，尾随垃圾、科学计数和混合后缀不再透传给后端。
- iperf3 的 `-l 14k` 保留原生参数，CTS 则按 1024 进制映射为 `DatagramByteSize:14336`；该长度超过常见 MTU，会产生 IP 分片。
- ctsTraffic 接收端 NIC 统计改为统一时间轴，并只计算 `Connected`、有效 `Traffic` 与 `Ended` 事件可以证明的数据窗口；monitor RPC、启动、握手、轮询和清理时间不再拉低平均速率。
- CTS 不再用 `Total Time`、正常退出或疑似缓冲输出补齐窗口，也不再在无样本时回退到全生命周期平均值。证据不足时明确返回 `NOT_EVALUATED / CTSTRAFFIC_EFFECTIVE_WINDOW_SHORT`，避免把统计假低误判为 `RATE_FAIL`；monitor 启停、无样本和窗口内采样错误均有独立原因码。
- Windows Release 包继续固定捆绑并校验 ctsTraffic 2.0.4.0；同时补充原生 ctsTraffic 双机手工命令。自动测试不能替代真实网卡、驱动、防火墙与 CPE 环境，发布后仍建议在两台真实 Windows 10+ 设备上完成 CTS TCP/UDP 双机数据流验收。

[![Rust](https://img.shields.io/badge/Rust-1.82%2B-orange)](https://rustup.rs)
[![License](https://img.shields.io/badge/license-MIT-blue)](LICENSE)
![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS-lightgrey)
[![CI](https://github.com/suikkg/cpe-test/actions/workflows/build.yml/badge.svg)](https://github.com/suikkg/cpe-test/actions/workflows/build.yml)

---

## 目录

- [概览](#概览)
- [快速开始](#快速开始)
- [命令行用法](#命令行用法)
- [网卡速率监控](#网卡速率监控)
- [配置文件](#配置文件)
- [模块架构](#模块架构)
- [角色分类体系](#角色分类体系)
- [截图与报告](#截图与报告)
- [RESUME 断点续跑](#resume-断点续跑)
- [跨平台策略](#跨平台策略)
- [编译与部署](#编译与部署)
- [常见问题](#常见问题)

---

## 概览

CPE（Customer Premises Equipment）子网测试工具用于在**两台电脑之间**自动化执行网络连通性和吞吐量测试，生成结构化的 HTML 报告。

**核心特性：**

- **Zero PowerShell** — 网卡扫描走 ipconfig + GetIfTable2 API + netsh wlan，不依赖 PowerShell 或 wmic
- **Zero 线程安全隐患** — 无 COM 多线程问题；agent 是固定线程池 + Arc\<Mutex\>，panic 不崩服务
- **单二进制分发** — 一个 exe 文件完成主控/辅测/监控三模式，不需要 pip install
- **REST + JSON** — 主控 ↔ 辅测走标准 HTTP，带超时/重试/错误码
- **双吞吐后端** — iperf3 跨平台通用测试；ctsTraffic 提供 Windows 10+ 专用 TCP/UDP 流量模型
- **20/32 流真实并发** — agent 的 HTTP worker 只创建/查询后台吞吐作业，不再被长时间 client 占住
- **UDP 连续采样** — 从起流前持续记录双端 RX/TX、流连接/重试/结束事件，结束后重建共同有效窗口
- **TCP/UDP 实时网卡速率** — 运行日志按秒打印 OS 网卡计数器的 `nic-rx`；工具输出用于确认起流和诊断，不替代 NIC 正式吞吐口径
- **原始记录独立落盘** — 每条流保存 client/server/事件和所有重试原文，并保存 NIC 逐样本 CSV
- **已知/未知目标分离** — EVB 已知目标正式验收；CPE、SGMII、RNDIS、WiFi 未知能力默认只测量，不伪造 PASS
- **独立网卡监控** — 不依赖子网测试流程，单独对某网口做逐秒速率采样，输出 CSV
- **按后端跨平台** — ping/iperf3 可在 Windows、macOS 等平台运行；ctsTraffic 仅支持 Windows 10+

---

## 快速开始

### 第 1 步：准备文件

把以下文件和目录放到两台电脑的同一目录：

```
cpe_test.exe          ← 本工具（单文件）
iperf3.exe            ← 从 iperf.fr 下载（只测 Ping/ctsTraffic 可不放）
ctsTraffic.exe        ← v4.4.0 Windows Release 已捆绑（仅 Windows 10+）
start_agent.bat       ← 辅测机双击
start_ui.bat          ← 主控机双击（图形控制台，推荐）
start_master.bat      ← 主控机双击（命令行问答式）
start_master_select_config.bat ← 主控机选择网口配置后双击
configs\             ← SGMII / Wi-Fi / 10GUSB 等具名配置
```

主控机和辅测机必须使用同一个 `cpe_test` 版本。选择 ctsTraffic 时，两台电脑都必须是
Windows 10 或更高版本，且都能在 `cpe_test.exe` 同目录或 `PATH` 中找到 `ctsTraffic.exe`。

### 第 2 步：辅测机启动 agent

双击 `start_agent.bat`，窗口里会显示本机 IP：

```
本机 IP 列表（把主控能 ping 通的那个告诉主控机）:
    以太网 = 192.168.8.101
    WLAN  = 10.228.46.50
agent 已启动，监听 0.0.0.0:28801
```

同时会自动打开**辅测机状态页** `http://127.0.0.1:28802`（只监听回环，局域网访问不到）：
运行状态（监听地址、token、iperf3/ctsTraffic 版本）、本机网卡表（主控要填的 IP 从这里挑，
主控连上后会标出它实际用的是哪一块）、实时活动（把几万行请求日志折叠成十来行
「启动 iperf3 服务端」「查询网卡采样 ×30」这样的动作；主控 token 填错会显示成红色失败记录）。
页面是只读的，不能从浏览器启停测试；不需要它就用 `cpe_test agent --no-ui`。

- **记录 IP**（选主控能连上的那个，一般是管理口）
- 防火墙提示时**全部放行**
- **不关窗口**

### 第 3 步：主控机测试

**图形控制台（推荐）**：双击 `start_ui.bat`，浏览器自动打开 `http://127.0.0.1:28800`。
页面里填辅测机 IP 点「连接」→ 需要的话逐网口填 RX 门限（`1800` 或 `90%` 协商速率百分比）
和发送端 UDP `-b` / `-l`
→ 勾选网口组合、方向、协议和 IP 版本（表头小勾选框是整列开关；「全选」连双向和 IPv6 一起勾）
→ 填 TCP `-w` / `-P` 与 UDP `-b` / `-l` / `-w` 档位（UDP 三项取组合，留空则该参数不下发）
→ 需要时勾「按链路上限裁剪 UDP -b」（默认不勾，填多少发多少）
→ 「预览任务」确认清单和预计耗时 → 「开始测试」，同页看实时进度，跑完打开报告。
控制台只监听本机回环，局域网上的其他机器访问不到。

**命令行问答式**：双击 `start_master_select_config.bat`，选择本次网口配置后输入辅测机 IP。
也可以双击 `start_master.bat`（默认 SGMII 配置），或以
`start_master.bat configs\\config-wifi5g.json` 指定配置：

```
请输入辅测机 IP: 192.168.8.101
```

程序自动扫描双端网卡 → 生成任务 → 执行 → 弹出 HTML 报告。

两条路径产出的报告完全一样：控制台只是把勾选结果写成一份 config，
再调用和命令行完全相同的执行流程。

---

## 命令行用法

```
cpe_test                    交互选择模式（双击运行就是这个，默认进图形控制台）
  菜单: [1] 图形控制台  [2] 子网测试(主控命令行)  [3] 辅测 agent  [4] 只看网卡  [5] 网卡速率监控

cpe_test ui                 图形控制台：浏览器里勾选执行
    --port N                控制台端口（默认 28800，只监听 127.0.0.1）
    --config FILE           指定配置文件（默认找 ./config.json）

cpe_test agent              辅测机启动常驻服务
    --port N                指定监听端口（默认 28801）
    --token SECRET          共享访问令牌（与主控一致才可连接）
    --bind IP               监听地址（默认 0.0.0.0）
    --ui-port N             本机状态页端口（默认 28802，只监听 127.0.0.1）
    --no-ui                 不起状态页，只跑服务

cpe_test master             主控发起测试
    --agent-host IP         辅测机 IP
    --agent-port N          辅测机端口（默认 28801）
    --token SECRET          与 agent 相同的共享访问令牌
    --config FILE           指定配置文件（默认找 ./config.json）
    --auto                  免交互：按配置文件 tests 全部执行
    --resume                24 小时内已 PASS 的任务跳过
    --no-open               结束后不自动打开报告
    --screenshot            每个吞吐任务后截图
    --prefix A.,B.          临时指定 IPv4 前缀过滤

cpe_test scan               查看本机网卡识别结果
    --prefix A.,B.

cpe_test monitor            独立网卡速率监控 (按 Ctrl+C 停止)
    --iface NAME / -n NAME  网卡名称 (不指定则用上次选择或交互选)
    --interval N / -i N     采样间隔秒数 (默认 1)
    --duration N / -d N     监控时长秒数 (0=不限，默认 0)
    --csv FILE / -c FILE    输出 CSV 文件路径 (可选)
```

---

## 网卡速率监控

`cpe_test monitor` 是独立于子网测试的网卡速率采样工具，适合**单台电脑**单独对某个网口做实时速率观测。

### 核心特性

- **DU Meter 同源精度** — 走 `GetIfTable2.InOctets` (Windows) / `netstat -ibn` (macOS)，64位累计字节差值法，不丢包
- **逐秒采样** — 可配采样间隔（1/2/5/10s），实时打印当前 Mbps
- **自动 CSV** — 测试期间实时追加写入，Ctrl+C 结束时自动在文件顶部注入平均值/峰值等统计摘要
- **记住上次网卡** — 第一次选完网卡后保存到 `.cpe_monitor_iface`，下次直接回车即可

### 用法示例

```bash
# 交互模式：列出网卡，选择后开始监控
cpe_test monitor

# 直接指定网卡，每秒采样，输出到 CSV
cpe_test monitor -n "以太网" -c speed_log.csv

# 每 5 秒采样一次，跑 120 秒自动停止
cpe_test monitor -n "以太网" -i 5 -d 120 -c r.csv
```

### 运行时输出

```
网卡: [以太网]  间隔: 1s  按 Ctrl+C 停止

时间                   速率(Mbps)
----------------------------------
2026-08-17 12:00:01       1690.10
2026-08-17 12:00:02       1688.50
^C
==================================================
网卡: 以太网
时长: 2s (2 次采样)
平均: 1689.30 Mbps
峰值: 1690.10 Mbps
最低: 1688.50 Mbps
CSV : speed_log.csv
```

### CSV 文件格式

文件顶部自动写入统计摘要（`#` 号行可被 pandas/Excel 自动跳过）：

```csv
# === CPE NIC Monitor Report ===
# Interface,以太网
# Interval,1s
# Duration,120s
# Average (Mbps),1685.30
# Peak (Mbps),1750.45
# ================================
Time,Speed(Mbps)
2026-08-17 12:00:01,1690.10
2026-08-17 12:00:02,1688.50
```

时间戳带完整日期，跨天的长时间监控也能直接定位问题发生的时刻。

---

## 配置文件

配置文件 `config.json` 放到 exe 同目录，所有测试参数通过 JSON 控制，**不需要改代码**。

JSON 标准没有注释，不能可靠地在同一个配置内用 `//`、`#` 或 `/* ... */` 来切换网口。
发布包的 `configs` 目录提供 `config-sgmii.json`、`config-wifi5g.json`、
`config-10gusb.json` 和 `config-all-common.json`；用 `--config` 或
`start_master_select_config.bat` 选择对应文件即可。需要自定义时复制最接近的一份再改，
不要往 JSON 添加注释。

完整字段：

```json
{
  "agent_host": "192.168.8.101",
  "agent_port": 28801,
  "ipv4_prefixes": ["192.168."],
  "require_same_subnet_for_iperf": true,
  "limit_udp_by_link_speed": true,
  "screenshot": false,
  "resume": false,
  "open_report": true,

  "pairs": "all",
  "universal_params": {
    "directions": ["A->B", "bidir"],
    "kinds": ["iperf", "ctstraffic", "ping"],
    "transports": ["tcp", "udp"],
    "ip": ["v4"],
    "streams": 5,
    "tcp_streams": 5,
    "udp_streams": 3,
    "iperf_duration": 180,
    "rate_mode": "auto",
    "rate_targets_mbps": {"forward": null, "ab": null, "ba": null}
  },
  "iperf": {
    "duration": 180,
    "tcp_windows": ["64k", "1m", "4m"],
    "udp_profiles": [
      { "bandwidth": "1m" },
      { "bandwidth": "500m" },
      { "bandwidth": "1000m", "length": "64", "window": "1m" },
      { "bandwidth": "2500m" }
    ]
  },

  "ctstraffic": {
    "udp_frame_rate": 100,
    "udp_buffer_depth_secs": 1,
    "status_update_ms": 1000
  },

  "ping": {
    "count": 100,
    "payload_sizes": [32, 1600, 65500]
  },

  "tests": [
    {
      "name": "2.5G口灌包",
      "src": "master:SGMII2.5G",
      "dst": "agent:SGMII2.5G",
      "direction": ["A->B", "bidir"],
      "kinds": ["ctstraffic", "ping"],
      "transports": ["tcp", "udp"],
      "ip": ["v4"],
      "streams": 5,
      "tcp_streams": 5,
      "udp_streams": 3,
      "iperf_duration": 180,
      "rate_mode": "observe"
    }
  ]
}
```

`require_same_subnet_for_iperf` 是为兼容旧配置保留的字段名，当前会同时约束跨机
iperf3 和 ctsTraffic 的 IPv4 直连任务。发布包预置配置默认仍使用
`["iperf", "ping"]`；要启用 CTS，将 `kinds` 改成 `["ctstraffic"]` 或上述组合即可。

### IP 自适应

配置写 `"master:SGMII2.5G"` 这种**角色引用**，运行时自动解析成当前机器的实际 IP。
换电脑不用改配置：角色识别对了，IP 自动跟着变。

兜底方案：`"master:NAME=以太网 2"` 按接口名精确匹配。

### tests[] 字段说明

| 字段 | 类型 | 说明 | 默认 |
|------|------|------|------|
| `name` | string | 测试名称 | — |
| `src` / `dst` | string | `"side:ROLE"` 或 `"side:NAME=接口名"` | — |
| `direction` | string/array | `"A->B" / "B->A" / "bidir" / "both"` | A->B |
| `kinds` | array | `iperf`、`ctstraffic`、`ping` 可任选或组合；`cts` 是 ctsTraffic 别名 | ["iperf"] |
| `transports` | array | `["tcp"] / ["udp"] / ["tcp","udp"]` | ["tcp"] |
| `ip` | array | `["v4"] / ["v6"]` | ["v4"] |
| `streams` | int | 兼容旧配置的通用并发流数；协议专用值缺省或为 0 时回退到此值 | 1 |
| `tcp_streams` | int | TCP 并发数；iperf3=`-P`，ctsTraffic=`Connections`，有效范围 `1..=32` | `streams` |
| `udp_streams` | int | UDP 并发数；iperf3=独立进程，ctsTraffic=`Connections`，有效范围 `1..=32` | `streams` |
| `iperf_duration` | int | 历史字段名，现供两种吞吐后端共用；映射规则见下文，必须大于 0 | — |
| `rate_mode` | string | `auto` / `verify` / `observe` / `discover` | 全局值 |
| `rate_targets_mbps` | object | `forward` 或双向 `ab`/`ba` 的明确验收目标；未知时保持 null | — |
| `ping_count` | int | 覆盖全局 ping 包数 | — |
| `ping_payload_sizes` | array | 覆盖全局负载字节；默认覆盖 32、1600、65500 | — |
| `tcp_windows` | array | TCP socket buffer 档位；ctsTraffic 映射为方向正确的 Send/Recv buffer | — |
| `udp_profiles` | array | UDP profile；支持严格带宽、可选 `length` 和可选 `window`，格式见下文 | — |

### pairs 自动配对（比 tests[] 更省事的写法）

如果你的测试场景是"主控上 N 个网口 × 辅测上 M 个网口，全部互相测一遍"，
不用逐个写 tests[]，用 `pairs` 一行搞定：

```json
{
  "pairs": "all",
  "universal_params": {
    "directions": ["A->B", "bidir"],
    "kinds": ["iperf", "ping"],
    "transports": ["tcp", "udp"],
    "ip": ["v4"],
    "streams": 1,
    "tcp_streams": 5,
    "udp_streams": 3,
    "iperf_duration": 180,
    "rate_mode": "auto"
  }
}
```

`pairs` 支持两种值：

| 值 | 含义 |
|---|---|
| `"all"` | 自动枚举主控 × 辅测所有网口两两组合（同 UNKNOWN 跳过） |
| `[{...}, ...]` | 手动列出角色对，每项 `{"master":"SGMII2.5G", "agent":"SGMII2.5G"}` |

`universal_params` 是统一应用给所有配对的测试参数；除名称和端点外，它支持与 `tests[]` 对应的测试参数，但方向字段写作复数 `directions`（`tests[]` 中为 `direction`）。未配置的参数使用全局默认值（`iperf.duration` / `ping.count` 等）。

`tcp_streams` 和 `udp_streams` 在 `universal_params` 与每个 `tests[]` 场景中都可用。
缺省或写 `0` 时沿用旧字段 `streams`；只选 TCP 或只选 UDP 时，未使用协议的专用值不参与校验。
交互菜单输入超出 `1..=32` 时会要求重输。配置文件中的越界值会先保留原值并提示：
iperf3 为兼容旧配置按 `1..=32` 夹取后执行，CTS 则不启动对应任务并记录
`SETUP_ERROR / CTSTRAFFIC_ARGS_INVALID`。

**优先级**：`tests[]` 非空时优先使用 `tests[]`。只有 `tests[]` 为空且 `pairs` 有值时，才走自动配对。

### ctsTraffic 后端（仅 Windows 10+）

在 `tests[].kinds` 或 `universal_params.kinds` 中使用 `"ctstraffic"`：

```json
"kinds": ["ctstraffic"]
```

也可以同一场景同时跑两种后端和 Ping，便于保留各自原始结果：

```json
"kinds": ["iperf", "ctstraffic", "ping"]
```

ctsTraffic 是 Windows 专用高级吞吐/可靠性工具，不是 iperf3 的替代实现。使用它时请注意：

- 主控和 agent 必须都是 Windows 10 或更高版本，并使用同一个 `cpe_test` 版本；两端都要能找到 `ctsTraffic.exe`。程序会实际解析本机 Windows 版本，只有 major 版本不低于 10 才通过，版本无法确认时按不支持处理。
- 程序会检查 `ctstraffic_v1` 能力、真实系统版本和两端二进制。任何一项不满足时，仅对应 CTS 单元记录 `SETUP_ERROR / CTSTRAFFIC_PREFLIGHT_FAILED`；不会静默改跑 iperf3，已选的 iperf3/Ping 仍继续。
- 配置中的 `src → dst` 始终表示数据方向。TCP Push 在 `src` 启动 ctsTraffic client 发送、在 `dst` 启动 server 接收；UDP MediaStream 则必须在 `src` 启动 server 发送、在 `dst` 启动 client 接收。程序已处理这层角色反转，报告仍按 `src → dst` 展示。
- TCP 使用 `tcp_streams`，UDP 使用 `udp_streams`，缺省或为 0 时分别回退到 `streams`。有效值映射为 client 的 `Connections:N`；一个 CTS 进程承载 N 条连接，不会像 iperf3 UDP 那样展开为 N 个进程。CTS 自动化要求所选协议的有效流数在 `1..=32`；配置文件超出范围会记录 `SETUP_ERROR / CTSTRAFFIC_ARGS_INVALID`，交互式输入则会要求重输，不会静默夹到边界值。
- 历史字段 `iperf_duration` 供两种吞吐后端共用。CTS TCP 映射为 client 的 `TimeLimit:<毫秒>`，这是硬截止；CTS UDP 映射为双方的 `StreamLength:<秒>`。CTS 自动化只接受 `1..=86400` 秒；配置文件中的 `duration=0` 不代表无限，也不会被静默修正为 1 秒，而是记录 `SETUP_ERROR / CTSTRAFFIC_ARGS_INVALID`；交互式输入会要求重输。若要使用 ctsTraffic 原生无限连接语义，请脱离本工具手工运行并自行停止。
- `tcp_windows` 对 CTS 表示 Winsock socket buffer：TCP 发送端用 `SendBufValue`、接收端用 `RecvBufValue`。`udp_profiles[].window` 对 iperf3 生成 `-w`，对 CTS UDP 则在 server 发送端使用 `SendBufValue`、client 接收端使用 `RecvBufValue`。这些都是 socket buffer，不是 TCP 拥塞窗口；非法尺寸会记录 `SETUP_ERROR / CTSTRAFFIC_ARGS_INVALID`。
- `udp_profiles[].bandwidth` 对每条 UDP 流生效。格式必须完整匹配十进制数值加可选 `k/m/g` 或 `kbps/mbps/gbps`（大小写不敏感，点或逗号均可作小数点，裸数兼容为 Mbps）；例如 `2.8G` 与 `2.8Gbps` 都是 2800 Mbps。合法值在交给 iperf3 前规范化为精确整数 bps。尾随垃圾、科学计数和混合后缀属于非法配置：iperf3 跳过该 profile 且不生成任务，CTS 为该 profile 记录 `SETUP_ERROR / CTSTRAFFIC_ARGS_INVALID`，两者都不会把原文交给后端尝试解析。对 CTS，合法值映射为每条连接的 `BitsPerSecond`，总提供速率约为“每流带宽 × 实际 `udp_streams`”。
- `udp_profiles[].length` 的 `k/m/g` 使用 1024 进制，因此 `14k` 精确等于 14336 字节；CTS 映射为 `DatagramByteSize` 且不得大于 65507 字节。14 KiB 明显超过常见 1500 字节 MTU，会产生 IP 分片；能正确解析不代表一定能获得更高吞吐或更低丢包。CTS 中无法解析或越界的 `bandwidth`/`length` 会记录 `SETUP_ERROR / CTSTRAFFIC_ARGS_INVALID`。默认 `FrameRate=100`、`BufferDepth=1`，属于 ctsTraffic MediaStream 模型，不等同于 iperf3 UDP flood。
- CTS UDP 的 `Connections:1` 与 iperf3 UDP 单流一样是每方向独立的硬连通门槛。总尝试数为 `max(flow_retries + 1, 3)`；双向 AB、BA 各自拥有完整预算并并行执行。每轮都必须完整启动 server/client，并在确认两端停止和资源清理完成后才可复用端口。
- 是否真正灌通只认工具自身的 rate、bytes、successful frames/datagrams 等证据；NIC RX 即使有背景流量也不能证明 CTS 连接已经建立。NIC 仅在工具已证明起流后用于验证正式目标吞吐、采样覆盖和稳定性。
- CTS 的接收端网卡样本与 client 事件统一对齐到每条测试腿的时间轴，只统计 `Connected`/首条有效状态到 `Ended` 推导出的真实数据窗口，不计入 monitor RPC、进程启动、握手、状态轮询或清理。`Total Time`、正常退出或疑似 stdout 缓冲都不会被用来补齐无法证明的数据时长；事件窗口不足时明确记录 `CTSTRAFFIC_EFFECTIVE_WINDOW_SHORT`。监控无样本时不会再回退到包含预热和清理的全生命周期平均值；启动、停止、运行采样失败会分别记录 `CTSTRAFFIC_MONITOR_START_FAILED`、`CTSTRAFFIC_MONITOR_STOP_FAILED`、`CTSTRAFFIC_MONITOR_RUNTIME_ERROR` 或 `CTSTRAFFIC_MONITOR_NO_SAMPLES`。
- 单连接在全部尝试均安全完成后仍没有 CTS 自身测量时，记录 `RATE_FAIL / CTSTRAFFIC_SINGLE_UDP_STREAM_FAILED`。平台、工具、参数、进程启动/状态查询、显式取消或清理未确认等在尚无测量时仍记录 `SETUP_ERROR`；一旦某轮已有工具测量，server 在显式停止前异常退出/超时或其他 CTS 运行错误会记录 `RATE_FAIL / CTSTRAFFIC_RUNTIME_ERRORS`，并按该轮真实 UDP 丢帧和目标速率判定，不用后续重试掩盖结果。
- CTS 不套用 iperf3 的“每个连接展开成独立进程”、settle、5 秒滚动 P10 和分阶段 `discover` 实现；CTS 使用 `discover` 时按固定 `Connections` 的能力测量记录为 `MEASURED`。两者只共享上述 UDP 单流硬连通与安全生命周期原则。
- iperf3 与 ctsTraffic 的连接模型、截止方式和 UDP 帧模型不同。报告可以并列保留两者，但不应把数值当成同一实现语义下的直接替换结果。

CTS 专用默认项：

| 字段 | 默认 | 含义 |
|------|------|------|
| `ctstraffic.udp_frame_rate` | 100 | UDP MediaStream 每秒帧数；每帧可再拆为 datagram |
| `ctstraffic.udp_buffer_depth_secs` | 1 | UDP client 应用层缓冲深度（秒），不是 socket buffer |
| `ctstraffic.status_update_ms` | 1000 | ctsTraffic 聚合状态输出周期（毫秒） |

`window`/`tcp_windows` 支持字节数以及 `k`、`m`、`g` 后缀，例如 `"64k"`、`"1m"`、
`"1.5m"`。UDP profile 省略 `window` 时维持旧行为，不会额外传入 socket buffer 参数。

### UDP 单流硬门槛与 iperf3 并发速率判定

UDP 单流、并发组和双向测试现在走同一套调度器：先把所有方向的 server 全部准备好，再按方向交错启动 client。网卡监控从起流前开始连续采样，直到最后一条流结束；最终根据流事件重建“哪些流在同一时刻真正有流量”的时间线。

`iperf.duration`（默认 180 秒）表示报告中用于判定的**有效稳态窗口**，不是 `iperf3 -t` 的固定进程墙钟时长。程序会自动加入背景采样、错峰起流、连接超时、稳定等待和失败流重试缓冲，所以一次 180 秒多流测试通常会运行约 200 秒；单流若需要完整执行多轮，墙钟时间还会按实际尝试数增加。报告会分别列出“有效秒数/要求秒数”。

失败流不会造成无限等待：

- iperf3 的瞬态连接错误先按原机制重试，组调度器还会重启对应 server/client。单向 1 流或双向每方向 1 流属于硬连通门槛，每个方向的总尝试数为 `max(flow_retries + 1, 3)`；双向 AB、BA 各自独立且并行。全部尝试安全完成后仍没有 iperf3 自身 rate/bytes/datagrams 证据时，记录 `RATE_FAIL / SINGLE_UDP_STREAM_FAILED`，不会降级为 `NOT_EVALUATED / ACTIVE_STREAMS_LOW`。
- 每次业务尝试都完整启动 server/client，结束后同步停止并等待子进程退出、输出线程回收；只有精确 `request_id` 的 server stop 和本轮清理均已确认，才会在同一端口启动下一轮。平台、工具、非法参数、server/client 启动或状态查询失败、显式取消以及停止未确认都属于 `SETUP_ERROR`，不会伪装成性能失败。
- 是否灌通只认 iperf3 自身 rate、bytes 或 datagrams 等输出证据，背景 NIC 流量不能把失败尝试变成成功。一旦某轮已有工具测量，就按该轮真实运行错误、UDP 丢包和目标速率继续判定，不靠额外重试掩盖真实结果。
- HTTP 传输重试复用同一个 `request_id`，因此 start 响应丢失不会重复创建进程；测试单元结束、报错或 panic 时还会按唯一 `owner_id` 批量清理 server/client/monitor。动态 lease 是断联后的最后兜底，不会用固定短 TTL 误杀合法长测。
- 2 条流的方向最低要求仍是 2 条。若最终只有 1 条成功，结果是 `NOT_EVALUATED / ACTIVE_STREAMS_LOW`，表示负载搭建不足，不会用单流速率误判 CPE 为 `RATE_FAIL`。
- 默认 `min_active_ratio=0.9`：5 条流要求至少 4 条，20 条要求至少 18 条；已知目标还会叠加 `ceil(目标 × 1.05 / 单流带宽)` 的 offered-load 要求。
- 运行中不阻塞等待并提前锁死窗口；结束后统一取满足活跃流条件的最长连续区间，迟到或提前结束只会如实改变该区间边界。
- 双向结果分别判断 AB/BA 目标，但使用“两边都达到各自最低活跃流数”的共同窗口，避免一边已满载、另一边仍在爬升时提前计分。

#### 网卡实测速率与 iperf 时间区间

报告里的“网卡 RX 平均/P10/中位/P95/最低/最高”和用于目标吞吐 PASS/FAIL 的正式接收速率始终来自接收端操作系统网卡累计字节计数器（Windows `GetIfTable2`、macOS `netstat -ibn`、Linux sysfs），不是 iperf3 自报速率。工具输出仍有一个不可替代的用途：必须由 iperf3/CTS 自身的 rate、bytes、frame/datagram 证据确认流确实建立；NIC 只验证已建立流的正式目标，不能用背景流量证明灌通。没有可信目标时只标记 `MEASURED`，不会仅因工具执行完成而标记 `PASS`。

TCP 和 UDP 运行期间现在使用同一套日志口径，例如：

```text
[灌包进度][TCP][ab] active=1/1 connected=1 ended=0 nic-rx=2368.4Mbps iperf=2379.0Mbps err=0
[灌包进度][UDP][ba] active=20/20 connected=20 ended=0 nic-rx=8420.3Mbps iperf=10000.0Mbps err=0
```

`nic-rx` 是接收端操作系统网卡累计字节差值得到的当期实际速率；`iperf` 只是 iperf3 interval 行的诊断值。旧版 iperf3 若块缓冲 stdout，运行中 `iperf` 可能暂时显示 `-`，但 `nic-rx` 仍会按网卡采样周期更新。实时 `nic-rx` 是未扣背景流量的网卡总速率，正式报告仍按共同有效窗口、背景基线和覆盖率规则计算。

旧版 iperf3 的 stdout 接到 pipe 后可能块缓冲，所有 interval 行会在结束时一瞬间刷出。如果直接用“第一行日志到最后一行日志”的墙钟差，180 秒测试会被误算成几毫秒。当前实现优先解析 iperf 行内的 `a-b sec`，按 `b-a` 反推真实活跃区间；解析不到时才回退到 Traffic/Connected/Started 事件。这个区间只负责裁剪网卡样本，不会把 iperf3 内部速率替换成正式网卡速率。

网卡平均值按每个样本与有效窗口的实际重叠毫秒数加权，覆盖率按有效时间并集计算。P10 来自完整覆盖的 5 秒滚动窗口；不足 5 秒不会用瞬时样本冒充 P10。计数器读取失败后跨多个周期的恢复样本可以补回总平均值，但不能伪造 5 秒稳定窗口。有明确目标时，RX/TX 总采样覆盖率和滚动窗口覆盖率都必须至少 95%，否则返回 `NOT_EVALUATED / SAMPLE_COVERAGE_LOW` 或 `RATE_WINDOW_COVERAGE_LOW`。

#### Ping 子网通信与自动故障诊断

常规 Ping 是**子网通信测试**，默认对每个所选方向分别覆盖 32、1600、65500 字节负载。`PASS` 的含义是“至少收到一个来自目标的 Echo Reply，子网可通信”；完整丢包率仍会写入日志和报告，但这里不是额外的 Ping 质量门槛。

Ping 解析只承认带 RTT 时间的真实 Echo Reply。Windows 的“目标不可达/一般故障”、macOS 的 ICMP Redirect 等额外 ICMP 行不会被算成目标回复，也不会再把与 Redirect 同时出现的真实回复误减掉。命令无法启动、超时、远端 HTTP/JSON 失败、源地址绑定失败等执行问题会报告为 `SETUP_ERROR / PING_EXEC_ERROR` 或 `PING_TIMEOUT`；只有命令正常完成但 0 个 Echo Reply 才报告为 `RATE_FAIL / PING_UNREACHABLE`。

如果本轮选择了吞吐测试，但所有 iperf3/ctsTraffic 单元都没有产生任何有效速率测量（包括缺少二进制、旧 agent 缺能力、所有 server 创建失败或所有 client 都未起流），主控会自动追加短时故障诊断：

- 按失败任务的每个唯一 IPv4 方向固定补跑 32 字节短 Ping，每个方向 3 包；自动诊断不再发送 1600/65500，避免故障时增加等待和无关变量。
- 对失败任务涉及的每块网卡，绑定该网卡 IPv4 源地址 Ping 该接口自己的 IPv4 默认网关，用于区分网卡/载体异常和吞吐后端搭建异常。
- 网卡没有 IPv4 默认网关时报告 `NOT_EVALUATED / GATEWAY_NOT_FOUND`，不会伪装成 100% 网络丢包。
- 已经选中的同方向 32 字节常规 Ping 不会重复执行；网关诊断仍会追加。

Windows 网关来自 `GetIpForwardTable2` 默认路由表并按接口索引关联；macOS 使用带 `-ifscope` 的默认路由查询。网卡扫描输出会显示 `gw:`，便于核对诊断目标。当前自动诊断不抓 PCAP；抓包留给后续 RF 自动化按异常条件启用，避免正常吞吐测试受到额外采集负担。

#### 主控/agent 版本与后端门禁

可靠 iperf3 生命周期由 agent `/health` 的 `reliable_lifecycle_v1` 能力声明，ctsTraffic 生命周期由 `ctstraffic_v1` 声明；运行中网卡快照由 `live_nic_progress_v1` 声明。主控在启动 server/client 前分别检查所选后端：iperf3 检查生命周期能力和两端 iperf3；ctsTraffic 则要求主控实际 Windows major 版本不低于 10，且 agent 只在自身同样通过真实版本检查时才声明 CTS 能力，然后再检查两端 `ctsTraffic.exe`。版本信息无法确认时 fail-closed。建议始终把同一个 Release 包完整复制到两台电脑。

检查失败只会阻断对应后端，并分别记录 `IPERF_PREFLIGHT_FAILED` 或 `CTSTRAFFIC_PREFLIGHT_FAILED`；不会静默回退，也不会阻断已选的另一吞吐后端或 Ping。只选 Ping 时仍兼容旧 agent，也不要求安装任何吞吐工具。

#### 速率模式

| 模式 | 适用场景 | 报告行为 |
|------|----------|----------|
| `auto` | 推荐默认 | 有显式目标或明确 EVB 10GUSB↔10GETH 路径时转 `verify`，否则转 `observe` |
| `verify` | 已知验收线 | 检查 TX offered load、RX 平均/P10、有效窗口和可选 UDP 丢包率；未提供显式或 EVB 自动目标时返回 `NOT_EVALUATED / TARGET_MISSING` |
| `observe` | CPE 理论/实际值未知 | 完整测量并输出速率统计，结果为 `MEASURED`，不伪造 PASS |
| `discover` | 首次摸底容量 | 约按 25%/50%/75%/100% 流数分阶段加压，报告附 `active_streams → avg/P10 RX` 表 |

自动目标只用于明确的 EVB 载体路径：

- `10GUSB/NCM → 10GETH`：默认 RX 目标 6400 Mbps。
- `10GETH → 10GUSB/NCM`：默认 RX 目标 8400 Mbps。
- NCM 显示 4.2G 是已知协商显示问题，按 10GUSB 能力处理；显示 10G 时同样处理。
- RNDIS 即使显示约 3.7G，默认可信负载上限仍为约 2500 Mbps。
- SGMII2.5G 上限约 2500 Mbps，SGMII1G 上限约 1000 Mbps；WiFi 取协商速率与 2500 Mbps 的较小值。
- NCM/10GUSB 经过 CPE 子网中的 SGMII、RNDIS 或 WiFi 时，offered load 按整条路径最低瓶颈裁剪，且默认仍是 `observe`，不会把 2.5G 上限直接当成产品 PASS 线。

EVB 自动目标可以在全局配置中调整：

```json
{
  "iperf": {
    "rate_check": {
      "evb_usb_to_eth_target_mbps": 6400,
      "evb_eth_to_usb_target_mbps": 8400
    }
  }
}
```

也可以按单个场景覆盖。下面配置中 `src=10GUSB`、`dst=10GETH`，所以 `ab` 是 USB→ETH，`ba` 是 ETH→USB：

```json
{
  "name": "EVB 双向自定义目标",
  "src": "master:10GUSB",
  "dst": "agent:10GETH",
  "direction": "bidir",
  "transports": ["udp"],
  "rate_mode": "verify",
  "rate_targets_mbps": {"ab": 6400, "ba": 8400}
}
```

目标优先级为：`tests[].rate_targets_mbps`（或 pairs 的 `universal_params.rate_targets_mbps`）→ 全局 `rate_check.targets_mbps` → 上述 EVB 角色自动目标。`ab` 始终表示配置中的 `src → dst`，`ba` 表示 `dst → src`；单向场景也可以使用 `forward`，因此交换 src/dst 后不要机械照抄 ab/ba 数值。

如果 CPE 已有经过评审的验收目标，应显式写入测试项：

```json
{
  "name": "CPE 双向回归",
  "src": "master:10GUSB",
  "dst": "agent:SGMII2.5G",
  "direction": "bidir",
  "transports": ["udp"],
  "streams": 5,
  "rate_mode": "verify",
  "rate_targets_mbps": {"ab": 2350, "ba": 2200}
}
```

#### `rate_check` 参数

| 字段 | 默认 | 含义 |
|------|------|------|
| `sample_interval_ms` | 1000 | RX/TX 连续采样周期，限制为 200～5000ms |
| `background_secs` | 3 | 起流前背景基线采样；统计会扣除中位背景流量 |
| `startup_timeout_secs` | 15 | 允许失败流快速重试及建立共同窗口的启动阶段 |
| `settle_secs` | 5 | 达到最低活跃流数后丢弃的稳定等待时间 |
| `launch_interval_ms` | 50 | 流之间错峰启动间隔；双向按流序号交错 |
| `min_concurrent_streams` | 2 | 多流测试允许正式计分的绝对最低流数 |
| `min_active_ratio` | 0.9 | 请求流数的最低活跃比例 |
| `offered_headroom_pct` | 5 | 验证目标所需的发送负载余量 |
| `flow_retries` | 1 | UDP 额外重试预算；一般为“初次尝试 + `flow_retries`”，iperf3 单流和 CTS `Connections:1` 每方向总尝试数强制为 `max(flow_retries + 1, 3)` |
| `discovery_step_secs` | 10 | discover 每个负载阶梯的保持时间 |
| `evb_usb_to_eth_target_mbps` | 6400 | EVB USB/NCM → 10G 以太方向的目标 |
| `evb_eth_to_usb_target_mbps` | 8400 | EVB 10G 以太 → USB/NCM 方向的目标 |
| `cpe_path_ceiling_mbps` | 2500 | RNDIS/SGMII2.5G/受限 CPE 路径的默认负载上限，不是 PASS 目标 |
| `max_udp_loss_pct` | null | 可选 UDP 丢包率上限；null 表示不作为门槛 |

完整的人工与自动验收矩阵见 [UDP并发灌包验收场景.md](UDP并发灌包验收场景.md)。

---

## 模块架构

```
cpe_test/
├── Cargo.toml
├── Cargo.lock
├── config.example.json      # 配置文件示例
├── src/
│   ├── main.rs              # CLI 入口 + 模式选择（master/agent/scan/monitor）
│   │
│   ├── agent/
│   │   ├── mod.rs
│   │   └── server.rs        # REST server（16 worker）+ 非阻塞吞吐作业 API
│   │
│   ├── master/
│   │   ├── mod.rs
│   │   ├── ui.rs            # 交互式菜单（复刻旧版交互逻辑）
│   │   ├── executor.rs      # 任务调度/执行/截图/结果库
│   │   └── builder.rs       # spec → 任务单元生成 + 端口分配
│   │
│   ├── nic/
│   │   ├── mod.rs           # scan_host() + 格式输出
│   │   ├── classify.rs      # 角色分类（纯逻辑，不分平台）
│   │   ├── scan_windows.rs  # ipconfig + GetIfTable2 + netsh wlan
│   │   ├── scan_macos.rs    # ifconfig + system_profiler + networksetup
│   │   └── monitor.rs       # NIC RX/TX 连续采样（Windows/macOS/Linux）
│   │
│   ├── cmd/
│   │   ├── mod.rs
│   │   ├── ipconfig.rs      # 解析 ipconfig /all（中英文）
│   │   ├── netsh.rs         # 解析 netsh wlan show interfaces
│   │   ├── iperf.rs         # iperf3 解析、流事件、server 和异步 client job 管理
│   │   └── ctstraffic.rs    # CTS 参数构造、输出解析与受控作业执行
│   │
│   ├── ping.rs              # ping 命令构造 + 执行 + 输出解析
│   │                        # （中/英/BSD 三格式，白名单策略排除 ICMP 错误应答）
│   ├── protocol.rs          # HTTP JSON 请求/响应类型定义
│   ├── config.rs            # JSON 配置文件加载
│   ├── rate.rs              # EVB/CPE 路径上限、已知/未知速率目标策略
│   ├── util.rs              # 子进程(超时/GBK)、日志、时间、辅助函数
│   ├── http_client.rs       # 极简 HTTP/1.1 客户端（零第三方依赖）
│   ├── screenshot.rs        # 截图（Windows GDI / macOS screencapture）
│   └── report.rs            # HTML 报告生成（单文件，内嵌样式）
│
├── .github/
│   └── workflows/
│       └── build.yml        # CI：Windows / macOS / Linux 自动编译 + Release
│
├── dist/                     # 部署用启动脚本（随 Release 分发）
│   ├── start_agent.bat
│   └── start_master.bat
│   ├── start_master_select_config.bat
│   └── configs/              # SGMII / Wi-Fi / 10GUSB 具名配置
│
├── NIC_README.md             # 网卡扫描技术详解
├── UDP并发灌包验收场景.md     # UDP 重构人工/自动验收矩阵
├── README.md
└── 使用说明.md               # 小白版图文教程
```

### 核心交互流程

```
辅测机                         主控机
  ┌──────────┐                ┌──────────────┐
  │  agent   │  HTTP POST     │   master     │
  │  :28801  │◄──────────────►│ 交互菜单/cfg │
  └────┬─────┘                └──────┬───────┘
       │                             │
  ┌────┴─────┐                 ┌─────┴──────┐
  │ nic/scan │                 │ master/    │
  │ ping     │                 │ builder    │
  │ iperf/CTS│                 │ executor   │
  │ monitor  │                 │ report     │
  │ screenshot│                └────────────┘
  └──────────┘
```

1. 主控启动 → 扫描本机 + POST `/info` 获取辅测机网卡
2. 配置文件或交互菜单 → 生成 `SpecNorm`（src/dst/方向/协议/流数）
3. builder → 解析角色名称为具体 IP，分配端口，生成 `Unit` 列表
4. executor → 逐个执行单元；按 iperf3 或 ctsTraffic 语义启动两端角色并持续采集 NIC
   - iperf3 UDP 会先准备所有方向的 server，失败时按流快速重试
   - 每个唯一端点只启动一个 RX/TX 连续采样器并采背景基线
   - 双向流按序号交错启动；远端 client 通过 `/iperf/client/start|status|stop` 后台作业执行
   - 优先用 iperf 行内 `a-b sec`（按 `b-a`）校准缓冲输出的活跃区间，再结合 Traffic/Retry/Ended 重建时间线并取双向共同有效窗口
   - ctsTraffic 通过 `/ctstraffic/start|status|stop` 管理一个承载 N 个 Connections 的作业，并按 TCP/UDP 的真实 client/server 方向启动
   - 分开计算 AB/BA 的 TX/RX 平均、P10、覆盖率、丢包率与原因码
5. 全部完成后生成 HTML 报告 + 自动打开

---

## 角色分类体系

```
角色             判定规则（按优先级从高到低）
───────────────  ───────────────────────────────────────────────
WIFI5G           是 WiFi 且频段 = 5GHz
WIFI2.4G         是 WiFi 且频段 = 2.4GHz
WIFI6G           是 WiFi 且频段 = 6GHz
WIFI             是 WiFi 但频段未知
10GUSB           高速 USB/NCM，速率 4001-12000 Mbps（兼容 NCM 4.2G bug）
RNDIS            描述含 "rndis" / "remote ndis"，优先于 USB/10G 字样
10GETH           速率 9000-12000 Mbps（描述不含 USB）
SGMII2.5G        速率 2400-2600 Mbps
SGMII1G          速率 900-1100 Mbps
RNDIS(兜底)      速率 3400-4000 Mbps
UNKNOWN          以上都不匹配
```

角色排序权重：`10GETH > 10GUSB > SGMII2.5G > SGMII1G > RNDIS > WIFI5G > WIFI6G > WIFI2.4G > WIFI > UNKNOWN`

---

## 原始记录、截图与报告

每次主控运行都会先创建独立目录 `runs/run_日期时间_进程号/`。报告、主控日志和全部附件都归档在这个 run 目录下：

```text
runs/run_日期时间_进程号/
├── report.html
├── master.log
└── iperf_outputs/
    ├── iperf_raw_*.log
    ├── ctstraffic_raw_*.log
    ├── nic_samples_*.csv
    └── screenshot_*.png
```

每个灌包单元完成并回收进程后，会在该 run 目录的 `iperf_outputs/` 保存：

- `iperf_raw_*.log`：client 命令、client stdout/stderr、server stdout/stderr、结构化流事件及所有重试 attempt。
- `ctstraffic_raw_*.log`：CTS 每轮 client/server 命令、stdout/stderr、解析摘要、生命周期和全部重试 attempt。
- `nic_samples_*.csv`：OS 网卡累计 RX/TX 字节、周期增量、当期 RX/TX Mbps、有效性和读取错误。

HTML 报告底部的“原始输出”仍内嵌便于查看的内容，并提供“独立原始记录”和“网卡逐样本 CSV”链接。`master.log` 只保存运行进度、摘要、错误和这些文件的路径，不重复塞入大体积的工具原文。复制报告给别人时，应连同整个 run 目录一起复制。`task_results.json` 仍放在外层作为跨运行的 RESUME 状态库。

### 截图流程

```
主控 → 截图请求（label=测试名_方向）
       │
       ├── 若接收端是本机 → capture_png() → PNG 字节
       └── 若接收端是辅测 → POST /screenshot → base64 PNG
               │
               ├── 两端各自尝试截图
               └── 任一成功 → 保存到当前 run 的 iperf_outputs/
                                命名: screenshot_{label}_{主控/辅测}_{时间戳}.png
                                报告链接: ./iperf_outputs/screenshot_xxx.png
```

- 两端都尝试截图，全部成功则报告中出现多个 `查看截图` 链接
- 辅测机不存盘，传完即丢（无磁盘残留）
- 请求失败、HTTP 状态异常、JSON/Base64 解析失败、截图 API 报错和本地写文件失败，都会把具体原因写入当前 run 目录的 `master.log`

### 报告列

| 列 | 说明 |
|------|------|
| 时间 / Task ID / Parent ID | 任务标识 |
| 任务 / IP / 传输 / 参数 | 测试描述 |
| 源/目标 PC / 接口 / IP | 网络端点 |
| 结果 | PASS / RATE_FAIL / UNSTABLE / MEASURED / NOT_EVALUATED / SETUP_ERROR / SKIP |
| 执行状态 / 原因码 / 原因详情 | 区分性能不达标、负载不足、窗口不足、连接或采样环境异常 |
| 请求/活跃/要求流、重试 | 展示真实并发建立情况；2 流只通 1 流时可直接定位 |
| 目标、TX 均值/P10 | 验证是否向 CPE 提供了足够 offered load |
| 网卡 RX 平均/P10/中位/P95/最低/最高 Mbps | **共同有效窗口内接收端 OS 网卡的权威吞吐口径** |
| 有效/要求秒、采样覆盖率 | 验证是否取得完整有效窗口；滚动窗口不足时原因详情会列出 RX/TX 覆盖百分比 |
| 对向接收 Mbps | 双向时对端实测吞吐 |
| 流量工具 sender/receiver 汇总（诊断） | iperf3 或 ctsTraffic 的工具自报证据，用于确认起流和诊断；不代替接收端 OS 网卡 RX 的正式吞吐口径 |
| UDP/Ping 丢包率 | 丢包百分比 |
| Ping 平均 ms | 平均时延 |
| 截图 / 执行命令 | 用于复现 |

---

## RESUME 断点续跑

24 小时内已 PASS 的任务自动跳过：

```bash
cpe_test master --auto --resume
```

跳过依据：`task_results.json` 中 task_id（MD5 稳定哈希）的 ok=true 且时间 < 24h。只有正式 `PASS` 会写入可跳过状态；`MEASURED`、`NOT_EVALUATED` 等不会被当成已通过。

---

## 跨平台策略

| 平台 | 角色 | 说明 |
|------|------|------|
| macOS | 主控/辅测 | ping/iperf3/报告可用；ctsTraffic 单元明确不支持 |
| Windows 10+ | 主控/辅测 | ping、iperf3、ctsTraffic 全部支持 |
| Linux | 编译/CI | ping/iperf3 部分功能可用；ctsTraffic 单元明确不支持 |

### 网卡扫描差异

| 功能 | Windows | macOS |
|------|---------|-------|
| 接口枚举 | `ipconfig /all` | `ifconfig -a` |
| 速率 | `GetIfTable2` API | `ifconfig -m` 解析 media 行 |
| WiFi | `netsh wlan show interfaces` | `networksetup` + `system_profiler` |
| IPv4 网关 | `GetIpForwardTable2` 按 InterfaceIndex | `route -n get -inet -ifscope <iface> default` |
| RX/TX 监控 | `GetIfTable2.InOctets/OutOctets` | `netstat -ibn` 的 Ibytes/Obytes |

### ping 输出解析

`ping.rs` 同时兼容 **Windows 中文 / Windows 英文 / macOS(BSD)** 三种 ping 输出格式：

```
Windows(中文):  来自 192.168.1.3 的回复: 字节=32 时间<1ms
Windows(英文):  Reply from 192.168.1.3: bytes=32 time<1ms
macOS:          64 bytes from 192.168.1.3: icmp_seq=0 ttl=64 time=1.605 ms
```

**白名单策略**：regression 发现 Windows 的 ping 统计行（"已发送=X，已接收=Y"）会把
ICMP 错误应答（"无法访问目标主机"、"TTL 传输中过期"、"一般故障"等）也计为"已接收"，
因为本机确实收到了一个回复包，只是不是来自目标主机的 echo reply。

修复：不维护错误消息黑名单，而是反向只认**有 RTT 时间**的目标回复行。逐行匹配
Windows 的 `的回复:` / `Reply from`，或 BSD/macOS 的 `bytes from + icmp_seq`；若该行没有
`时间[<=]\d` 或 `time[<=]\d`，就不是目标 Echo Reply。统计行只提供实际发送数和接收上限，
最终 `received` 必须有逐包 Echo Reply 证据，因此 Redirect 与不可达都不会被算成功。

```
统计行显示:           已发送=4，已接收=4，丢失=0 (0%丢失)
逐行核查后修正:       已接收=0，丢失=4，丢包率=100%  ← ok=false
```

---

## 编译与部署

### macOS 本地调试

```bash
cargo test --locked
cargo build --release --locked
./target/release/cpe_test scan
```

### macOS → Windows 交叉编译

```bash
rustup target add x86_64-pc-windows-gnu
brew install mingw-w64
cargo build --release --locked --target x86_64-pc-windows-gnu
# 产物: target/x86_64-pc-windows-gnu/release/cpe_test.exe
```

### Windows 本地编译（推荐，更稳定）

```bash
# 装一次 rustup: https://rustup.rs （5 分钟）
cargo build --release --locked
# 产物: target\release\cpe_test.exe
```

自行编译后，把 `cpe_test.exe`、启动脚本和所需吞吐工具放到两台 Windows 电脑同一目录：
iperf3 测试需要完整的 iperf3 Windows 发行包；ctsTraffic 测试需要 `ctsTraffic.exe`。
官方 v4.4.0 Windows Release ZIP 已捆绑固定且校验过的 ctsTraffic 2.0.4.0，但由于发行包差异不内置 iperf3。

### GitHub Actions CI

每次推送 tag（`v*`）会先执行 `cargo fmt --check`、`cargo test --locked` 和 `cargo clippy --locked --all-targets -- -D warnings`，全部通过后才锁定依赖编译 Windows / macOS / Linux 三平台并发布到 Release 页面。
手动触发：Actions → Build Release → Run workflow。

配置文件 `.github/workflows/build.yml`：
- `windows-latest` → `x86_64-pc-windows-msvc` 
- `macos-latest` → `aarch64-apple-darwin`
- `ubuntu-latest` → `x86_64-unknown-linux-gnu`

Release 资产使用平台唯一名称，避免不同系统的 `cpe_test` 相互覆盖：

- `cpe_test-<tag>-windows-x86_64.zip`
- `cpe_test-<tag>-macos-aarch64.tar.gz`
- `cpe_test-<tag>-linux-x86_64.tar.gz`
- `SHA256SUMS`

Windows ZIP 包含启动脚本、四份配置、固定 CTS 二进制和第三方许可；Unix 使用
`tar.gz` 保留 `cpe_test` 可执行位。发布作业会再次核对资产名称、数量、内部结构和哈希。

仓库同时跟踪一份不含可执行程序的
[`cpe_test-v4.4.0-windows-config-docs.zip`](dist/cpe_test-v4.4.0-windows-config-docs.zip)，
便于直接从 Git 下载 Windows 配置、文档和启动脚本。其 SHA-256 位于同目录的
`.zip.sha256` 文件；CI 会逐文件确认压缩包内容与仓库源文件一致。需要开箱即用的程序、
固定版 ctsTraffic 和许可证全集时，仍应下载上面的正式 Windows Release ZIP。

---

## 常见问题

### agent 连不上

1. 辅测机的 agent 窗口开着吗？
2. IP 输对了吗？（用辅测机窗口里显示的）
3. 防火墙放行了吗？最快验证：`ping 辅测机IP`
4. 还不行关掉防火墙试一下

### 未找到 iperf3

把 `iperf3.exe`（含同目录的 cygwin1.dll 等）放到 `cpe_test.exe` 同目录。
只测 Ping 或 ctsTraffic 可以不装 iperf3。

### ctsTraffic 不可用或被前置检查阻断

- ctsTraffic 只支持 Windows 10 或更高版本，程序会检查真实 Windows major 版本；Windows 7/8/8.1、版本无法确认以及 macOS/Linux 都不会尝试启动，也不会自动改跑 iperf3。
- 把 `ctsTraffic.exe` 放到两台电脑各自的 `cpe_test.exe` 同目录，或加入 `PATH`；官方 Windows Release ZIP 已包含它。
- 主控和 agent 必须使用同一个 `cpe_test` Release。旧 agent 没有 `ctstraffic_v1` 能力时会记录 `CTSTRAFFIC_PREFLIGHT_FAILED`。
- 只想继续其他测试时，可把 `kinds` 改为 `["iperf", "ping"]`；只有 CTS 单元会被阻断。

### 网卡列表空白/不全

- 运行 `cpe_test scan --prefix 你本机的网段` 验证
- 默认只认 `192.168.` 开头的 IP，改 `config.json` 的 `ipv4_prefixes`
- 断开的网卡不显示

### 测试中途 Ctrl+C 能出报告吗？批处理和直接运行有区别吗？

- 第一次 Ctrl+C：安全停止当前单元后的流程并照常生成 HTML 报告与 CSV（部分结果在内）；第二次 Ctrl+C 才是强制退出。
- 直接运行 `cpe_test.exe` 或在 cmd/PowerShell 里运行，第一次 Ctrl+C 即优雅停止并出报告。
- 从 `start_master.bat` / `start_agent.bat` 启动时，cmd.exe 收到 Ctrl+C 可能额外弹出
  "Terminate batch job (Y/N)?"，**请按 N**（不要按 Y），批处理会等待工具优雅退出并写出报告。

### 灌包全 FAIL 但 ping 通
- 两端都准备了所选后端吗（iperf3 或 ctsTraffic）？
- 防火墙拦了 56000+ 端口？
- 两端 IP 不同网段？关掉 `require_same_subnet_for_iperf`

### UDP 大档位没生成任务

默认按整条路径的可信负载上限裁剪：RNDIS/SGMII2.5G 约 2.5G、SGMII1G 约 1G，WiFi 取协商速率与 2.5G 的较小值。关掉 `limit_udp_by_link_speed` 可以强制生成，但可能只是在制造发送端拥塞，不建议作为正式验收口径。

### UDP 单向 1 流或双向每方向 1 流始终不通，怎么判

iperf3 UDP 单流和 CTS UDP `Connections:1` 都是每方向独立的硬连通门槛。每个方向总尝试数为 `max(flow_retries + 1, 3)`，双向 AB、BA 各自独立并行；每轮都要完整启动并确认 server/client 清理完成。全部安全尝试仍没有工具自身 rate/bytes/frame/datagram 证据时，iperf3 记录 `RATE_FAIL / SINGLE_UDP_STREAM_FAILED`，CTS 记录 `RATE_FAIL / CTSTRAFFIC_SINGLE_UDP_STREAM_FAILED`。缺工具、平台不支持、非法参数、尚无测量时的生命周期或清理失败仍是 `SETUP_ERROR`；非法 CTS `window`/`bandwidth`/`length`/`streams`/`duration` 的具体原因码为 `CTSTRAFFIC_ARGS_INVALID`。一旦已有 CTS 工具测量，server 在显式停止前异常退出或超时则记录 `RATE_FAIL / CTSTRAFFIC_RUNTIME_ERRORS`，并按真实运行错误、丢包/丢帧和目标速率判定，不通过继续重试掩盖结果。

### 2 条 UDP 流只通了 1 条，会不会直接判性能 FAIL

不会。失败流会先在启动阶段重试；若最终仍是 1/2，报告为 `NOT_EVALUATED / ACTIVE_STREAMS_LOW`，表示 offered load 搭建不足。该轮不会拿单流速率判断 CPE 吞吐，也不会写入 RESUME PASS。

### 20/32 条流是否仍会被 agent 的 16 worker 分两批

不会。`/iperf/client/start` 只创建后台作业并立即返回，长时间运行的 iperf3 不占 HTTP worker；主控通过 status 轮询事件。日志中的 `[灌包进度][UDP] active=...` 和报告“请求/活跃/要求流”可验证实际并发数。

### 灌包原始记录在哪里

HTML 报告底部仍有“原始输出”。此外，iperf3 会在当前 run 的 `iperf_outputs/` 生成 `iperf_raw_*.log`，ctsTraffic 会生成 `ctstraffic_raw_*.log`，网卡监控会生成 `nic_samples_*.csv`；重试不会覆盖前一次原文。`master.log` 不重复写全部原始行，只记录进度和文件路径。报告、日志和附件位于同一个 run 目录中。

### 报告的 RX/P10 是 iperf3 内部速率还是网卡实际速率

是接收端操作系统网卡计数器的实际速率。iperf3 行内的 `0.00-180.00 sec` 只用来识别真实活跃时间，解决 stdout 缓冲导致日志时间差只有几毫秒的问题；它不会参与正式 RX 平均或 P10 数值计算。工具自报值不替代网卡吞吐口径，但 rate/bytes/frame/datagram 等工具自身证据仍是确认单流确实灌通的必要条件，背景 NIC 流量不能替代它。

### 灌包失败重试前会不会先释放端口

会。两种 UDP 后端每轮都先停止 client，再按本轮 `request_id` 精确停止 server，并确认进程已经 `wait` 回收、输出 reader 已结束；确认成功后才允许同端口的下一轮 start。若 kill/wait 或远端确认失败，该方向立即停止重试并报告 `SETUP_ERROR`，单元末尾还会按 `owner_id` 再做批量补偿清理。

### 截图空白/无

- Windows agent 需要 GDI 授权（通常首次跑会自动弹窗）
- macOS 终端需要系统设置 → 隐私 → 屏幕录制 授权
- 截图失败不改变吞吐判定；具体 API/HTTP/解析/写盘原因会记录在当前 run 目录的 `master.log`
